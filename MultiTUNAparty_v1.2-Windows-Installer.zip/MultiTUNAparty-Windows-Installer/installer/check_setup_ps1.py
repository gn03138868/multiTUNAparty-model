#!/usr/bin/env python3
"""
check_setup_ps1.py -- guard against the class of bug that broke the first release.

Windows PowerShell 5.1 reads a script file in the system ANSI code page unless the
file carries a UTF-8 byte-order mark. Without a BOM, every non-ASCII character in
setup.ps1 is misdecoded, string literals lose their closing quotes, and the whole
file fails to parse -- which is exactly what happened on a zh-TW machine.

This script checks, without needing PowerShell installed:

  1. the UTF-8 BOM is present;
  2. quotes, here-strings, braces, parentheses and brackets all balance;
  3. no bare '%' appears in code (it is the ForEach-Object alias and is easy to
     leave inside an argument string by accident);
  4. every backtick line-continuation is the last character on its line;
  5. generated .bat content stays ASCII (cmd.exe reads .bat in the OEM code page).

Run it after any edit:

    python check_setup_ps1.py installer/setup.ps1

Exit code 0 = clean, 1 = problems found.

Author: Shitephen Wang   Licence: MIT
"""

from __future__ import annotations

import pathlib
import re
import sys


def tokenize(src: str):
    """Walk the script, tracking which lexical state each character is in.

    Returns (issues, final_state, bracket_depths, code_percent_lines).
    """
    issues: list[str] = []
    depth = {"{": 0, "(": 0, "[": 0}
    closer = {"}": "{", ")": "(", "]": "["}
    pct: list[int] = []

    i, n, line, state = 0, len(src), 1, "code"

    while i < n:
        c = src[i]
        nxt = src[i + 1] if i + 1 < n else ""

        if c == "\n":
            line += 1
            if state == "line_comment":
                state = "code"
            elif state in ("here_dq", "here_sq"):
                q = '"' if state == "here_dq" else "'"
                # a here-string ends with  "@  (or '@) at the start of a line
                if src[i + 1 : i + 3] == q + "@":
                    state = "code"
                    i += 3
                    continue
            i += 1
            continue

        if state == "code":
            if c == "<" and nxt == "#":
                state = "block_comment"; i += 2; continue
            if c == "#":
                state = "line_comment"; i += 1; continue
            if c == "@" and nxt == '"':
                state = "here_dq"; i += 2; continue
            if c == "@" and nxt == "'":
                state = "here_sq"; i += 2; continue
            if c == '"':
                state = "dq"; i += 1; continue
            if c == "'":
                state = "sq"; i += 1; continue
            if c == "`":
                i += 2
                if nxt == "\n":
                    line += 1
                continue
            if c == "%":
                pct.append(line)
            if c in depth:
                depth[c] += 1
            elif c in closer:
                depth[closer[c]] -= 1
                if depth[closer[c]] < 0:
                    issues.append(f"line {line}: unmatched '{c}'")
                    depth[closer[c]] = 0
            i += 1
            continue

        if state == "block_comment":
            if c == "#" and nxt == ">":
                state = "code"; i += 2; continue
            i += 1; continue

        if state == "line_comment":
            i += 1; continue

        if state == "sq":
            if c == "'" and nxt == "'":
                i += 2; continue
            if c == "'":
                state = "code"
            i += 1; continue

        if state == "dq":
            if c == "`":
                i += 2; continue
            if c == '"' and nxt == '"':
                i += 2; continue
            if c == '"':
                state = "code"
            i += 1; continue

        i += 1  # inside a here-string

    return issues, state, depth, pct


def main() -> int:
    path = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "installer/setup.ps1")
    if not path.is_file():
        print(f"not found: {path}")
        return 1

    raw = path.read_bytes()
    issues: list[str] = []

    # 1 -- the BOM
    has_bom = raw.startswith(b"\xef\xbb\xbf")
    if not has_bom:
        issues.append(
            "MISSING UTF-8 BOM. Windows PowerShell 5.1 will misread every non-ASCII "
            "character and fail to parse the file. Save as 'UTF-8 with BOM'."
        )
    src = raw[3:].decode("utf-8") if has_bom else raw.decode("utf-8", "replace")

    # 2 -- lexical structure
    tok_issues, state, depth, pct = tokenize(src)
    issues += tok_issues
    if state != "code":
        issues.append(f"file ends inside state '{state}': unterminated string or comment")
    for ch, d in depth.items():
        if d:
            issues.append(f"unbalanced '{ch}': {d:+d}")

    # 3 -- bare % in code
    if pct:
        issues.append(f"bare '%' in code at line(s) {pct} (ForEach-Object alias)")

    # 4 -- backtick continuations
    for k, l in enumerate(src.split("\n"), 1):
        if l.strip().startswith("#"):
            continue
        if re.search(r"`[ \t]+\S", l):
            issues.append(f"line {k}: backtick continuation is not at end of line")

    # 5 -- generated .bat content must be ASCII
    for m in re.finditer(r'@"\n(.*?)\n"@', src, re.S):
        block = m.group(1)
        if "@echo off" in block:
            bad = [c for c in set(block) if ord(c) > 127]
            if bad:
                line = src[: m.start()].count("\n") + 1
                issues.append(
                    f"line {line}: generated .bat contains non-ASCII {bad!r}; "
                    "cmd.exe reads .bat in the OEM code page and will mojibake it"
                )

    nonascii = sum(1 for l in src.split("\n") if any(ord(c) > 127 for c in l))
    print(f"{path}")
    print(f"  {len(raw):,} bytes, {len(src.splitlines())} lines, "
          f"{nonascii} lines containing non-ASCII")
    print(f"  UTF-8 BOM: {'present' if has_bom else 'MISSING'}")
    print()
    if issues:
        print(f"=== {len(issues)} ISSUE(S) ===")
        for x in issues:
            print("  !", x)
        return 1
    print("=== OK: BOM present, structure balanced, no bare %, .bat blocks ASCII ===")
    return 0


if __name__ == "__main__":
    sys.exit(main())
