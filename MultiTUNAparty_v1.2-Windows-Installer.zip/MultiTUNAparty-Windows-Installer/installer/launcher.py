"""
launcher.py -- MultiTUNAparty
Starts the desktop interface with the trained model already loaded.

The point of this file is that the person using the software never has to
browse for a checkpoint, set a device, or click "Load Model". They double-click
one icon and the program is ready to work.

It does not modify app_gui_en.py. It imports it, sets the model path from the
installer's config.json, and triggers the normal load routine once the window
exists -- so any change to the GUI keeps working here.

Author: Shitephen Wang
Licence: MIT
"""

from __future__ import annotations

import json
import os
import sys
import traceback
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
INSTALL_ROOT = APP_DIR.parent
CONFIG = INSTALL_ROOT / "config.json"
ERROR_LOG = INSTALL_ROOT / "error_log.txt"

os.chdir(APP_DIR)
sys.path.insert(0, str(APP_DIR))


def find_model() -> str | None:
    """Locate the trained model: env var, then config.json, then the usual folders."""
    env = os.environ.get("MULTITUNAPARTY_MODEL")
    if env and Path(env).is_file():
        return env
    if CONFIG.is_file():
        try:
            p = json.loads(CONFIG.read_text(encoding="utf-8")).get("model_path", "")
            if p and Path(p).is_file():
                return p
        except Exception:
            pass
    for cand in (INSTALL_ROOT / "models" / "best_model.pth",
                 APP_DIR / "outputs" / "models" / "best_model.pth",
                 APP_DIR / "best_model.pth"):
        if cand.is_file():
            return str(cand)
    return None


def report(exc: BaseException) -> None:
    """Write a readable crash report and show it, rather than vanishing silently."""
    text = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    try:
        ERROR_LOG.write_text(text, encoding="utf-8")
    except Exception:
        pass
    try:
        import tkinter as tk
        from tkinter import messagebox
        r = tk.Tk(); r.withdraw()
        messagebox.showerror(
            "MultiTUNAparty",
            "程式啟動時發生問題。\nThe program could not start.\n\n"
            f"{type(exc).__name__}: {exc}\n\n"
            f"詳細訊息已存到 / details saved to:\n{ERROR_LOG}")
        r.destroy()
    except Exception:
        print(text)


def main() -> int:
    import tkinter as tk
    try:
        import app_gui_en as gui_module
    except Exception as exc:
        report(exc)
        return 1

    root = tk.Tk()
    try:
        gui = gui_module.MultiTaskGUI(root)
    except Exception as exc:
        report(exc)
        return 1

    model = find_model()
    if model:
        try:
            gui.model_path_var.set(model)
            # give the window a moment to appear, then load exactly as the
            # Load Model button does
            root.after(600, gui.load_model)
            gui.update_status("正在載入模型... / Loading the model...")
        except Exception:
            gui.update_status("請到 Model Management 分頁載入模型 / "
                              "Please load a model on the Model Management tab")
    else:
        gui.update_status("找不到模型檔 / No model file found")
        # A non-technical user should be told what to do, not left with a
        # status-bar line they may never read.
        def prompt_for_model():
            try:
                from tkinter import messagebox
                messagebox.showinfo(
                    "MultiTUNAparty",
                    "還沒有模型檔。\n\n"
                    "請到「Model Management」分頁，按 Browse 選擇 best_model.pth，"
                    "再按 Load Model。\n\n"
                    "或把 best_model.pth 放到這個資料夾，然後重新開啟程式：\n"
                    f"{INSTALL_ROOT / 'models'}\n\n"
                    "---\n\n"
                    "No model file yet.\n\n"
                    "Go to the Model Management tab, click Browse, choose "
                    "best_model.pth and click Load Model.\n\n"
                    "Or put best_model.pth in the folder above and reopen "
                    "the program.")
            except Exception:
                pass
        root.after(700, prompt_for_model)

    # make sure the outputs folders the GUI writes to exist
    for sub in ("outputs/models", "outputs/predictions", "outputs/batch_predictions"):
        (APP_DIR / sub).mkdir(parents=True, exist_ok=True)

    root.mainloop()
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:  # last resort
        report(exc)
        sys.exit(1)
