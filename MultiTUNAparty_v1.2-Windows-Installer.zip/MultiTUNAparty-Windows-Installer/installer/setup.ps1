﻿<#
    MultiTUNAparty - Windows one-click installer

    Installs everything needed to run MultiTUNAparty without typing a single
    command afterwards. Per-user install; no administrator rights required.

    Run via INSTALL.bat

    ENCODING NOTE: this file MUST be saved as UTF-8 WITH a byte-order mark.
    Windows PowerShell 5.1 reads script files in the system ANSI code page
    unless a BOM is present, which corrupts the non-ASCII strings below and
    breaks parsing. If you edit this file, save it as "UTF-8 with BOM".

    Author: Shitephen Wang   Licence: MIT
#>

param(
    [string]$SourceDir  = "",     # folder holding app_gui_en.py etc.
    [string]$ModelFile  = "",     # local best_model.pth to use instead of downloading
    [string]$ModelUrl   = "https://github.com/gn03138868/multiTUNAparty-model/releases/latest/download/best_model.pth",
    [switch]$CpuOnly,             # force the CPU build of PyTorch
    [switch]$EnglishOnly,         # suppress the Chinese half of every message
    [switch]$Quiet
)

$ErrorActionPreference = "Stop"
$ProgressPreference    = "SilentlyContinue"   # much faster Invoke-WebRequest

function Invoke-Native {
    <# Run an external program and return its combined output plus exit code.

       With $ErrorActionPreference = "Stop" in force, merging a native command's
       stderr into the output stream (2>&1) makes PowerShell raise a terminating
       NativeCommandError on the first stderr line. pip writes warnings there as
       a matter of course, so a perfectly ordinary install would abort the whole
       script. Inside this function the preference is relaxed and success is
       decided by the exit code, which is what it should have been all along. #>
    param([string]$Exe, [string[]]$Arguments)
    $ErrorActionPreference = "Continue"
    $output = & $Exe @Arguments 2>&1
    return [pscustomobject]@{ Output = $output; ExitCode = $LASTEXITCODE }
}

# ---------------------------------------------------------------------------
# console encoding, and a bilingual message helper that degrades to English
# ---------------------------------------------------------------------------

$script:Bilingual = $false
if (-not $EnglishOnly) {
    try {
        [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
        $OutputEncoding = [System.Text.Encoding]::UTF8
        $script:Bilingual = $true
    } catch {
        $script:Bilingual = $false   # console cannot show UTF-8; English only
    }
}

function T {
    <# Return "<Chinese> / <English>" when the console can render it, else English. #>
    param([string]$Zh, [string]$En)
    if ($script:Bilingual -and $Zh) { return "$Zh / $En" }
    return $En
}

# ---------------------------------------------------------------------------
# paths and logging
# ---------------------------------------------------------------------------

$AppName     = "MultiTUNAparty"
$InstallRoot = Join-Path $env:LOCALAPPDATA $AppName
$PyDir       = Join-Path $InstallRoot "python"
$EnvDir      = Join-Path $InstallRoot "env"
$AppDir      = Join-Path $InstallRoot "app"
$ModelDir    = Join-Path $InstallRoot "models"
$LogFile     = Join-Path $InstallRoot "install_log.txt"

$PythonVersion = "3.11.9"
$PythonUrl     = "https://www.python.org/ftp/python/$PythonVersion/python-$PythonVersion-amd64.exe"

New-Item -ItemType Directory -Force -Path $InstallRoot | Out-Null

function Log {
    param([string]$Message, [string]$Colour = "Gray")
    $stamp = (Get-Date).ToString("HH:mm:ss")
    Add-Content -Path $LogFile -Value "[$stamp] $Message" -Encoding UTF8
    if (-not $Quiet) { Write-Host $Message -ForegroundColor $Colour }
}

function Step {
    param([int]$Number, [string]$Title)
    if (-not $Quiet) {
        Write-Host ""
        Write-Host "[$Number/8] $Title" -ForegroundColor Cyan
    }
    Add-Content -Path $LogFile -Value "`r`n===== [$Number/8] $Title =====" -Encoding UTF8
}

function Fail {
    param([string]$What, [string]$Advice)
    Write-Host ""
    Write-Host "  X  $What" -ForegroundColor Red
    Write-Host ""
    Write-Host "     $Advice" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "     $(T '完整紀錄' 'full log'):  $LogFile" -ForegroundColor DarkGray
    Add-Content -Path $LogFile -Value "FAILED: $What" -Encoding UTF8
    Write-Host ""
    Read-Host "     $(T '按 Enter 關閉' 'Press Enter to close')"
    exit 1
}

if (-not $SourceDir) { $SourceDir = Split-Path -Parent $PSScriptRoot }
# A caller passing "%~dp0" hands us a path whose trailing backslash escaped the
# closing quote, leaving a stray double quote on the end. Repair it.
$SourceDir = $SourceDir.Trim().Trim('"').TrimEnd('\')
if (-not (Test-Path $SourceDir)) {
    $fallback = Split-Path -Parent $PSScriptRoot
    if (Test-Path $fallback) { $SourceDir = $fallback }
}

Add-Content -Path $LogFile -Value "`r`n########## $(Get-Date) ##########" -Encoding UTF8
Log "Install root : $InstallRoot"
Log "Source dir   : $SourceDir"
Log "PowerShell   : $($PSVersionTable.PSVersion)  bilingual=$($script:Bilingual)"

if (-not $Quiet) {
    Write-Host ""
    Write-Host "  ==========================================================" -ForegroundColor White
    Write-Host "   MultiTUNAparty  -  $(T '安裝程式' 'Installer')" -ForegroundColor White
    Write-Host "   $(T '細胞、根、真菌影像的辨識與量化' 'Identify and measure cells, roots and fungal structures')" -ForegroundColor Gray
    Write-Host "  ==========================================================" -ForegroundColor White
    Write-Host ""
    Write-Host "   $(T '安裝位置' 'Installs to'):" -ForegroundColor Gray
    Write-Host "   $InstallRoot" -ForegroundColor DarkGray
    Write-Host ""
    Write-Host "   $(T '不需要系統管理員權限，不會更動系統設定' 'No administrator rights needed; nothing system-wide is changed')" -ForegroundColor Gray
    Write-Host "   $(T '需要約 15-30 分鐘與 8 GB 磁碟空間' 'Takes about 15-30 minutes and 8 GB of disk space')" -ForegroundColor Gray
    Write-Host ""
}

# ---------------------------------------------------------------------------
# 1. disk space
# ---------------------------------------------------------------------------

Step 1 (T "檢查磁碟空間" "Checking disk space")
try {
    $drive = (Get-Item $InstallRoot).PSDrive.Name
    $free  = (Get-PSDrive $drive).Free / 1GB
    $freeTxt = "{0:N1}" -f $free
    Log "  $(T '可用空間' 'free space'): $freeTxt GB"
    if ($free -lt 8) {
        Fail (T "磁碟空間不足" "Not enough disk space") `
             (T "請清出至少 8 GB 後重新執行。" "Free up at least 8 GB and run this again.")
    }
    Log "  OK" "Green"
} catch {
    Log "  $(T '無法確認磁碟空間，繼續' 'could not check disk space, continuing')" "Yellow"
}

# ---------------------------------------------------------------------------
# 2. Python
# ---------------------------------------------------------------------------

Step 2 (T "準備 Python" "Setting up Python")

function Test-UsablePython {
    <# Needs Python 3.9-3.12 AND tkinter, which the graphical interface depends on. #>
    param([string]$Exe)
    if (-not (Test-Path $Exe)) { return $false }
    try {
        # Deliberately avoids the '%' character: it is the ForEach-Object alias in
        # PowerShell and has caused parse trouble inside quoted argument strings.
        $code = "import sys,tkinter" + [char]59 + "print(str(sys.version_info[0])+'.'+str(sys.version_info[1]))"
        $r = Invoke-Native $Exe @("-c", $code)
        if ($r.ExitCode -ne 0) { return $false }
        $first = ($r.Output | Where-Object { $_ -is [string] -and $_.Trim() } | Select-Object -First 1)
        if (-not $first) { return $false }
        $parts = $first.ToString().Trim().Split('.')
        if ($parts.Count -lt 2) { return $false }
        $maj = [int]$parts[0]; $min = [int]$parts[1]
        return ($maj -eq 3 -and $min -ge 9 -and $min -le 12)
    } catch { return $false }
}

$python = $null
$bundled = Join-Path $PyDir "python.exe"
if (Test-UsablePython $bundled) {
    $python = $bundled
    Log "  $(T '使用先前安裝的 Python' 'reusing the Python installed earlier')" "Green"
} else {
    foreach ($cand in @("python", "python3", "py")) {
        try {
            $cmd = Get-Command $cand -ErrorAction SilentlyContinue
            if ($cmd -and $cmd.Source -and (Test-UsablePython $cmd.Source)) {
                $python = $cmd.Source
                Log "  $(T '找到系統上的 Python' 'found Python already on this computer'): $python" "Green"
                break
            }
        } catch { }
    }
}

if (-not $python) {
    Log "  $(T '這台電腦沒有合用的 Python，正在下載安裝（約 25 MB）' 'No suitable Python found; downloading and installing it (about 25 MB)')"
    $inst = Join-Path $env:TEMP "python-$PythonVersion-amd64.exe"
    try {
        Invoke-WebRequest -Uri $PythonUrl -OutFile $inst -UseBasicParsing
    } catch {
        Fail (T "無法下載 Python" "Could not download Python") `
             (T "請檢查網路連線後重試。" "Check your internet connection and try again.")
    }
    Log "  $(T '安裝中，請稍候' 'installing, please wait')..."
    $pyArgs = @("/quiet", "InstallAllUsers=0", "PrependPath=0", "Include_tcltk=1",
                "Include_pip=1", "Include_test=0", "AssociateFiles=0", "Shortcuts=0",
                "TargetDir=$PyDir")
    $proc = Start-Process -FilePath $inst -ArgumentList $pyArgs -Wait -PassThru
    Remove-Item $inst -ErrorAction SilentlyContinue
    if (-not (Test-UsablePython $bundled)) {
        $msg = (T "Python 安裝失敗" "Python installation failed") + " (exit code $($proc.ExitCode))"
        Fail $msg (T "請手動安裝 Python 3.11 並勾選 tcl/tk，再重新執行本程式。" "Install Python 3.11 manually with the tcl/tk option, then run this again.")
    }
    $python = $bundled
    Log "  $(T 'Python 安裝完成' 'Python installed')" "Green"
}

$verCode = "import sys" + [char]59 + "print('.'.join(map(str,sys.version_info[:3])))"
$pyver = ((Invoke-Native $python @("-c", $verCode)).Output | Select-Object -First 1).ToString().Trim()
Log "  Python $pyver"

# ---------------------------------------------------------------------------
# 3. virtual environment
# ---------------------------------------------------------------------------

Step 3 (T "建立獨立執行環境" "Creating an isolated environment")

$venvPy = Join-Path $EnvDir "Scripts\python.exe"
if (-not (Test-Path $venvPy)) {
    $r = Invoke-Native $python @("-m", "venv", $EnvDir)
    Add-Content -Path $LogFile -Value ($r.Output -join "`r`n") -Encoding UTF8
    if (-not (Test-Path $venvPy)) {
        Fail (T "無法建立執行環境" "Could not create the environment") `
             (T "請確認防毒軟體沒有阻擋，然後重試。" "Check that antivirus software is not blocking it, then retry.")
    }
}
Log "  $(T '完成' 'done'): $EnvDir" "Green"

$r = Invoke-Native $venvPy @("-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel", "--quiet")
Add-Content -Path $LogFile -Value ($r.Output -join "`r`n") -Encoding UTF8

# ---------------------------------------------------------------------------
# 4. detect the graphics card
# ---------------------------------------------------------------------------

Step 4 (T "偵測顯示卡" "Detecting the graphics card")

$gpuName = ""
$torchIndex = ""
if ($CpuOnly) {
    Log "  $(T '依指定使用 CPU 版本' 'CPU build requested')" "Yellow"
    $torchIndex = "https://download.pytorch.org/whl/cpu"
} else {
    try {
        $r = Invoke-Native "nvidia-smi" @("--query-gpu=name", "--format=csv,noheader")
        if ($r.ExitCode -eq 0 -and $r.Output) {
            $first = ($r.Output | Where-Object { $_ -is [string] -and $_.Trim() } | Select-Object -First 1)
            if ($first) { $gpuName = $first.ToString().Trim() }
        }
    } catch { }

    if ($gpuName) {
        Log "  $(T '找到 NVIDIA 顯示卡' 'NVIDIA GPU found'): $gpuName" "Green"
        # RTX 50-series (Blackwell) needs the newer CUDA build
        if ($gpuName -match "RTX\s*50\d\d" -or $gpuName -match "Blackwell") {
            $torchIndex = "https://download.pytorch.org/whl/cu128"
            Log "  $(T '使用 CUDA 12.8 版本' 'using the CUDA 12.8 build')"
        } else {
            $torchIndex = "https://download.pytorch.org/whl/cu124"
            Log "  $(T '使用 CUDA 12.4 版本' 'using the CUDA 12.4 build')"
        }
    } else {
        Log "  $(T '沒有找到 NVIDIA 顯示卡，將使用 CPU（速度較慢但完全可用）' 'No NVIDIA GPU found; using the CPU build (slower, but fully working)')" "Yellow"
        $torchIndex = "https://download.pytorch.org/whl/cpu"
    }
}

# ---------------------------------------------------------------------------
# 5. install packages
# ---------------------------------------------------------------------------

Step 5 (T "安裝必要套件（這一步最久，請耐心等候）" "Installing packages (this is the slow step)")

function Install-Package {
    <# Install one package, returning $true on success. On failure the tail of
       pip's own output is printed, because burying it in the log leaves the
       user with nothing actionable. #>
    param([string]$Spec, [string]$IndexUrl = "", [switch]$WheelsOnly)
    $cmdArgs = @("-m", "pip", "install", "--disable-pip-version-check", $Spec)
    if ($IndexUrl)   { $cmdArgs += @("--index-url", $IndexUrl) }
    if ($WheelsOnly) { $cmdArgs += @("--only-binary=:all:") }
    $r = Invoke-Native $venvPy $cmdArgs
    $out = $r.Output
    $code = $r.ExitCode
    Add-Content -Path $LogFile -Value "`r`n--- pip install $Spec (exit $code) ---" -Encoding UTF8
    Add-Content -Path $LogFile -Value ($out -join "`r`n") -Encoding UTF8
    if ($code -eq 0) { return $true }
    Write-Host ""
    Write-Host "      pip $(T '失敗' 'failed'): $Spec" -ForegroundColor Red
    $tail = $out | Select-Object -Last 15
    foreach ($l in $tail) { Write-Host "      $l" -ForegroundColor DarkGray }
    Write-Host ""
    return $false
}

Log "  $(T '正在下載 PyTorch，約 2-3 GB' 'downloading PyTorch, about 2-3 GB')..."
$torchOk = Install-Package "torch" $torchIndex
if ($torchOk) { $torchOk = Install-Package "torchvision" $torchIndex }
if (-not $torchOk) {
    Log "  $(T '指定版本失敗，改用一般版本' 'that build failed, falling back to the default build')" "Yellow"
    $torchOk = (Install-Package "torch") -and (Install-Package "torchvision")
}
if (-not $torchOk) {
    Fail (T "PyTorch 安裝失敗" "PyTorch installation failed") `
         (T "多半是網路中斷。請重新執行本程式，已下載的部分會被沿用。" "Usually a dropped connection. Run this installer again; what already downloaded is reused.")
}

# Core packages: the prediction interface cannot run without these.
$coreFile = Join-Path $PSScriptRoot "requirements-core.txt"
$failedCore = @()
if (Test-Path $coreFile) {
    $core = Get-Content $coreFile | Where-Object { $_.Trim() -and -not $_.TrimStart().StartsWith("#") }
    $total = $core.Count
    $k = 0
    foreach ($pkg in $core) {
        $k++
        $name = ($pkg -split "[<>=!~]")[0].Trim()
        Write-Host "      [$k/$total] $name" -ForegroundColor DarkGray
        if (-not (Install-Package $pkg.Trim())) { $failedCore += $name }
    }
}
if ($failedCore.Count -gt 0) {
    Fail ((T "必要套件安裝失敗" "Required packages failed") + ": " + ($failedCore -join ", ")) `
         (T "先重新執行一次本程式，有時只是網路中斷。若同一個套件再次失敗，請把上面的 pip 訊息和紀錄檔寄給開發者。" "Run this installer again first: it is often just a dropped connection. If the same package fails twice, send the pip messages above and the log file to the developer.")
}
Log "  $(T '必要套件安裝完成' 'required packages installed')" "Green"

# Optional packages: only the training interface needs these, so a failure here
# must not stop the installation.
$optFile = Join-Path $PSScriptRoot "requirements-optional.txt"
$script:FailedOptional = @()
if (Test-Path $optFile) {
    Log "  $(T '安裝訓練介面用的套件（失敗不影響辨識功能）' 'installing packages for the training interface (a failure here does not affect prediction)')..."
    $opt = Get-Content $optFile | Where-Object { $_.Trim() -and -not $_.TrimStart().StartsWith("#") }
    foreach ($pkg in $opt) {
        $name = ($pkg -split "[<>=!~]")[0].Trim()
        Write-Host "      $name" -ForegroundColor DarkGray
        # wheels only: a laboratory computer has no C++ compiler and should not need one
        $ok = Install-Package $pkg.Trim() -WheelsOnly
        if (-not $ok -and $name -eq "albumentations") {
            # recent albumentations pulls stringzilla, which ships no wheel for
            # every platform. 1.4.x releases before that dependency work fine.
            Log "      $(T '改試較舊版本' 'trying an earlier release')..." "Yellow"
            foreach ($alt in @("albumentations==1.4.10", "albumentations==1.3.1")) {
                if (Install-Package $alt -WheelsOnly) { $ok = $true; break }
            }
        }
        if (-not $ok) { $script:FailedOptional += $name }
    }
}
if ($script:FailedOptional.Count -gt 0) {
    Log "  $(T '以下套件沒裝成功，只影響訓練介面' 'these did not install; only the training interface is affected'): $($script:FailedOptional -join ', ')" "Yellow"
} else {
    Log "  $(T '全部套件安裝完成' 'all packages installed')" "Green"
}

# ---------------------------------------------------------------------------
# 6. copy the application
# ---------------------------------------------------------------------------

Step 6 (T "安裝程式檔案" "Installing the application files")

New-Item -ItemType Directory -Force -Path $AppDir, $ModelDir | Out-Null

$needed = @("app_gui_en.py", "app_train_en.py", "model_multitask_boundaryversion.py",
            "dataset_multitask.py", "losses_multitask.py", "train_multitask_optimized.py",
            "config_training_ui.yaml")

# The installer ships its own copy of the application under app\, so it works on
# a computer that has never seen the project. If it happens to sit next to a
# checkout of the repository, that copy wins, because it is the newer one.
$searchDirs = @(
    $SourceDir,
    (Join-Path $SourceDir "app"),
    (Join-Path (Split-Path -Parent $PSScriptRoot) "app"),
    $PSScriptRoot
) | Where-Object { $_ -and (Test-Path $_) } | Select-Object -Unique

$appSource = $null
foreach ($d in $searchDirs) {
    if (Test-Path (Join-Path $d "app_gui_en.py")) { $appSource = $d; break }
}
if ($appSource) {
    Log "  $(T '程式檔來源' 'application files from'): $appSource"
} else {
    Log "  $(T '在以下位置都找不到 app_gui_en.py' 'app_gui_en.py not found in any of'):" "Yellow"
    foreach ($d in $searchDirs) { Log "    $d" "Yellow" }
}

$copied = 0
foreach ($f in $needed) {
    $found = $false
    foreach ($d in @($appSource) + $searchDirs) {
        if (-not $d) { continue }
        $src = Join-Path $d $f
        if (Test-Path $src) {
            Copy-Item $src -Destination $AppDir -Force
            $copied++; $found = $true; break
        }
    }
    if (-not $found) { Log "  $(T '缺少' 'missing'): $f" "Yellow" }
}
# the GUI imports `model_multitask`; provide it under that name too
$bv = Join-Path $AppDir "model_multitask_boundaryversion.py"
if (Test-Path $bv) { Copy-Item $bv -Destination (Join-Path $AppDir "model_multitask.py") -Force }

Copy-Item (Join-Path $PSScriptRoot "launcher.py") -Destination $AppDir -Force
Copy-Item (Join-Path $PSScriptRoot "train_launcher.py") -Destination $AppDir -Force
Log "  $(T '複製了' 'copied') $copied $(T '個程式檔' 'application files')" "Green"

if ($copied -eq 0) {
    Fail (T "找不到程式檔" "Could not find the application files") `
         (T "安裝檔應該自帶 app 資料夾。請把整個 zip 重新解壓縮一次，不要只取出 INSTALL.bat。" "The installer ships an app folder of its own. Re-extract the whole zip rather than pulling out INSTALL.bat alone.")
}

# ---------------------------------------------------------------------------
# 7. model weights
# ---------------------------------------------------------------------------

Step 7 (T "準備模型權重" "Getting the trained model")

$target = Join-Path $ModelDir "best_model.pth"
if (Test-Path $target) {
    $mb = [math]::Round((Get-Item $target).Length / 1MB)
    Log "  $(T '已存在，略過下載' 'already present, skipping') ($mb MB)" "Green"
} else {
    $local = ""
    if ($ModelFile -and (Test-Path $ModelFile)) {
        $local = $ModelFile
    } else {
        $guesses = @(
            (Join-Path $SourceDir "best_model.pth"),
            (Join-Path $SourceDir "outputs\models\best_model.pth"),
            (Join-Path $SourceDir "models\best_model.pth"),
            (Join-Path $SourceDir "app\best_model.pth"),
            (Join-Path (Split-Path -Parent $PSScriptRoot) "best_model.pth")
        )
        foreach ($guess in $guesses) {
            if (Test-Path $guess) { $local = $guess; break }
        }
    }
    if ($local) {
        Log "  $(T '從本機複製' 'copying from this computer'): $local"
        Copy-Item $local -Destination $target -Force
    } else {
        Log "  $(T '下載模型權重，約 500 MB' 'downloading the model, about 500 MB')..."
        try {
            Invoke-WebRequest -Uri $ModelUrl -OutFile $target -UseBasicParsing
        } catch {
            if (Test-Path $target) { Remove-Item $target -Force -ErrorAction SilentlyContinue }
            Log "  $(T '下載失敗' 'download failed'): $($_.Exception.Message)" "Yellow"
            Log "  $(T '安裝會繼續，但第一次使用要自己指定模型檔。' 'Installation continues, but you will need to point the software at a model file the first time.')" "Yellow"
        }
    }
    if (Test-Path $target) {
        $mb = [math]::Round((Get-Item $target).Length / 1MB)
        Log "  $(T '完成' 'done') ($mb MB)" "Green"
    }
}
$script:HaveModel = Test-Path $target

$cfg = [ordered]@{
    model_path   = $target
    app_dir      = $AppDir
    installed_at = (Get-Date).ToString("s")
    gpu          = $gpuName
    torch_index  = $torchIndex
    version      = "1.1"
} | ConvertTo-Json
Set-Content -Path (Join-Path $InstallRoot "config.json") -Value $cfg -Encoding UTF8

# ---------------------------------------------------------------------------
# 8. shortcuts and self-test
# ---------------------------------------------------------------------------

Step 8 (T "建立捷徑並測試" "Creating shortcuts and testing")

# Generated .bat files are ASCII only: cmd.exe reads them in the OEM code page,
# so non-ASCII text in a .bat is unreliable.
$runPredict = Join-Path $InstallRoot "MultiTUNAparty.bat"
@"
@echo off
title MultiTUNAparty
cd /d "$AppDir"
"$EnvDir\Scripts\pythonw.exe" "$AppDir\launcher.py" %*
if errorlevel 1 (
  echo.
  echo The program exited with a problem.
  echo Details: "$InstallRoot\error_log.txt"
  pause
)
"@ | Set-Content -Path $runPredict -Encoding ASCII

$runTrain = Join-Path $InstallRoot "MultiTUNAparty_Training.bat"
@"
@echo off
chcp 65001 >nul 2>&1
set PYTHONIOENCODING=utf-8
title MultiTUNAparty - Training
cd /d "$AppDir"
"$EnvDir\Scripts\python.exe" "$AppDir\train_launcher.py"
if errorlevel 1 pause
"@ | Set-Content -Path $runTrain -Encoding ASCII

$uninstall = Join-Path $InstallRoot "Uninstall.bat"
@"
@echo off
title Uninstall MultiTUNAparty
echo.
echo This will remove MultiTUNAparty from this computer.
echo Your images and results are NOT touched - only the program itself.
echo.
set /p ok=Type Y to remove, anything else to cancel:
if /i not "%ok%"=="Y" exit /b 0
del "%USERPROFILE%\Desktop\MultiTUNAparty.lnk" 2>nul
rmdir /s /q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\MultiTUNAparty" 2>nul
cd /d "%TEMP%"
rmdir /s /q "$InstallRoot"
echo.
echo Removed.
pause
"@ | Set-Content -Path $uninstall -Encoding ASCII

function New-Shortcut {
    param([string]$Path, [string]$Target, [string]$Arguments,
          [string]$WorkDir, [string]$Description, [string]$Icon = "")
    try {
        $ws = New-Object -ComObject WScript.Shell
        $sc = $ws.CreateShortcut($Path)
        $sc.TargetPath       = $Target
        if ($Arguments) { $sc.Arguments = $Arguments }
        $sc.WorkingDirectory = $WorkDir
        $sc.Description      = $Description
        if ($Icon -and (Test-Path $Icon)) { $sc.IconLocation = $Icon }
        $sc.Save()
        return $true
    } catch { return $false }
}

$desktop = [Environment]::GetFolderPath("Desktop")
$startMenu = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\$AppName"
New-Item -ItemType Directory -Force -Path $startMenu | Out-Null

# Two icons: a tuna in a doctoral cap for the program itself, a young tuna for
# the training interface. Two separate pictures matter more than they sound --
# both shortcuts land on the same Desktop, and one icon on both would make them
# tell apart only by the text under them.
$icon = Join-Path $AppDir "MultiTUNAparty.ico"
$iconTrain = Join-Path $AppDir "MultiTUNAparty_Training.ico"
foreach ($pair in @(@("MultiTUNAparty.ico", $icon), @("MultiTUNAparty_Training.ico", $iconTrain))) {
    $src = Join-Path $PSScriptRoot $pair[0]
    if (Test-Path $src) { Copy-Item $src -Destination $pair[1] -Force }
}
if (-not (Test-Path $icon))      { $icon = "" }
if (-not (Test-Path $iconTrain)) { $iconTrain = $icon }

# A folder under Documents for the user's own images and training results, so
# that nothing they care about lives inside LOCALAPPDATA where they would never
# look for it. train_launcher.py owns the layout; ask it, so there is one
# definition of that layout rather than two that can drift apart.
$script:Workspace = ""
$prep = Invoke-Native (Join-Path $EnvDir "Scripts\python.exe") `
        @((Join-Path $AppDir "train_launcher.py"), "--prepare-only")
if ($prep.ExitCode -eq 0 -and $prep.Output) {
    $line = ($prep.Output | Select-Object -Last 1 | Out-String).Trim()
    if ($line -and (Test-Path $line)) { $script:Workspace = $line }
}
if (-not $script:Workspace) {
    $script:Workspace = Join-Path ([Environment]::GetFolderPath("MyDocuments")) $AppName
    foreach ($rel in @("data\train\other\images", "data\train\other\masks",
                       "data\val\other\images",   "data\val\other\masks",
                       "outputs\models")) {
        New-Item -ItemType Directory -Force -Path (Join-Path $script:Workspace $rel) | Out-Null
    }
}
Log "  $(T '你的資料夾' 'your folder'): $script:Workspace" "Green"

$pythonw = Join-Path $EnvDir "Scripts\pythonw.exe"
$launchArgs = '"' + (Join-Path $AppDir "launcher.py") + '"'
$desc = "Identify and measure cells, roots and fungal structures"

$made = 0
if (New-Shortcut (Join-Path $desktop   "MultiTUNAparty.lnk") $pythonw $launchArgs $AppDir $desc $icon) { $made++ }
if (New-Shortcut (Join-Path $startMenu "MultiTUNAparty.lnk") $pythonw $launchArgs $AppDir $desc $icon) { $made++ }
if (New-Shortcut (Join-Path $startMenu "MultiTUNAparty Training.lnk") $runTrain "" $AppDir "Train your own model" $iconTrain) { $made++ }
if (New-Shortcut (Join-Path $desktop   "MultiTUNAparty Training.lnk") $runTrain "" $AppDir "Train your own model" $iconTrain) { $made++ }
if ($script:Workspace -and (Test-Path $script:Workspace)) {
    if (New-Shortcut (Join-Path $startMenu "MultiTUNAparty Data Folder.lnk") $script:Workspace "" $script:Workspace "Your own images and training results" "") { $made++ }
}
if (New-Shortcut (Join-Path $startMenu "Uninstall MultiTUNAparty.lnk") $uninstall "" $InstallRoot "Remove MultiTUNAparty" "") { $made++ }
Log "  $(T '建立了' 'created') $made $(T '個捷徑' 'shortcuts')" "Green"

# Explorer caches shortcut icons by file path. Reinstalling over a previous
# version writes new artwork to the same path, and without this the Desktop
# keeps showing yesterday's picture until the user logs out.
try { Start-Process -FilePath "ie4uinit.exe" -ArgumentList "-show" -WindowStyle Hidden -ErrorAction SilentlyContinue } catch { }

Log "  $(T '測試安裝結果' 'testing the installation')..."
$testLines = @(
    "import sys, os",
    "sys.path.insert(0, r'$AppDir')",
    "import torch, cv2, numpy, PIL, matplotlib, yaml, tkinter",
    "print('torch', torch.__version__)",
    "print('cuda_available', torch.cuda.is_available())",
    "if torch.cuda.is_available(): print('gpu', torch.cuda.get_device_name(0))",
    "import model_multitask",
    "print('model_module_ok')"
)
$testFile = Join-Path $env:TEMP "mtp_selftest.py"
Set-Content -Path $testFile -Value $testLines -Encoding UTF8
$out = (Invoke-Native $venvPy @($testFile)).Output
Remove-Item $testFile -ErrorAction SilentlyContinue
Add-Content -Path $LogFile -Value ($out -join "`r`n") -Encoding UTF8

$cudaOk  = [bool]($out | Select-String -SimpleMatch "cuda_available True")
$modelOk = [bool]($out | Select-String -SimpleMatch "model_module_ok")
if (-not $modelOk) {
    Fail (T "自我測試沒有通過" "The self-test did not pass") `
         (T "請把紀錄檔寄給開發者。" "Please send the log file to the developer.")
}
Log "  $(T '測試通過' 'test passed')" "Green"

# ---------------------------------------------------------------------------

if (-not $Quiet) {
    Write-Host ""
    Write-Host "  ==========================================================" -ForegroundColor Green
    Write-Host "   $(T '安裝完成！' 'Installation complete!')" -ForegroundColor Green
    Write-Host "  ==========================================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "   $(T '桌面上會出現一個圖示：MultiTUNAparty' 'Look for the MultiTUNAparty icon on your Desktop')" -ForegroundColor White
    Write-Host "   $(T '點兩下就可以開始。模型會自動載入，不需要任何設定。' 'Double-click it to start. The model loads by itself.')" -ForegroundColor Gray
    Write-Host ""
    Write-Host "   $(T '要訓練自己的標的：桌面上的「MultiTUNAparty Training」' 'To train your own target class: the MultiTUNAparty Training icon on your Desktop')" -ForegroundColor Gray
    Write-Host "   $(T '（也在開始功能表的 MultiTUNAparty 資料夾裡）' '(also in the MultiTUNAparty folder in the Start menu)')" -ForegroundColor DarkGray
    Write-Host ""
    if ($script:Workspace) {
        Write-Host "   $(T '你自己的影像和訓練結果放在這裡：' 'Your own images and training results live here:')" -ForegroundColor White
        Write-Host "   $script:Workspace" -ForegroundColor Cyan
        Write-Host "   $(T '訓練用的資料夾已經建好了，把影像和遮罩放進去就可以。' 'The folders training needs are already made; just put your images and masks in.')" -ForegroundColor DarkGray
        Write-Host ""
    }
    if (-not $script:HaveModel) {
        Write-Host "   $(T '尚未取得模型檔。第一次打開程式時：' 'No model file yet. The first time you open the program:')" -ForegroundColor Yellow
        Write-Host "   $(T '  到 Model Management 分頁，按 Browse 選擇 best_model.pth' '  go to the Model Management tab, click Browse and choose best_model.pth')" -ForegroundColor Yellow
        Write-Host "   $(T '  或把 best_model.pth 放到下面這個資料夾再重開程式：' '  or put best_model.pth in this folder and reopen the program:')" -ForegroundColor Yellow
        Write-Host "   $ModelDir" -ForegroundColor DarkGray
        Write-Host ""
    }
    if ($script:FailedOptional -and $script:FailedOptional.Count -gt 0) {
        Write-Host "   $(T '注意：訓練介面所需的套件未安裝完成' 'Note: packages for the training interface did not install'): $($script:FailedOptional -join ', ')" -ForegroundColor Yellow
        Write-Host "   $(T '辨識與量測功能不受影響。' 'Prediction and measurement are unaffected.')" -ForegroundColor Yellow
        Write-Host ""
    }
    if ($cudaOk) {
        Write-Host "   $(T '顯示卡加速：已啟用' 'GPU acceleration: on') ($gpuName)" -ForegroundColor Green
    } else {
        Write-Host "   $(T '顯示卡加速：未啟用，將使用 CPU（較慢但完全可用）' 'GPU acceleration: off, running on CPU (slower but fully working)')" -ForegroundColor Yellow
    }
    Write-Host ""
    Write-Host "   $(T '要移除時，直接刪除這個資料夾即可：' 'To uninstall, just delete this folder:')" -ForegroundColor DarkGray
    Write-Host "   $InstallRoot" -ForegroundColor DarkGray
    Write-Host ""
    Read-Host "   $(T '按 Enter 關閉' 'Press Enter to close')"
}
