﻿#Requires -Version 5.1
<#
    update_existing.ps1 -- MultiTUNAparty

    Brings an installation that is already on this computer up to date without
    reinstalling Python, PyTorch or the model, which is the part that takes
    twenty minutes. It replaces the launcher scripts and the artwork, rebuilds
    the shortcuts, and creates the user's data folder.

    Run it through UPDATE.bat rather than directly.

    Author: Shitephen Wang   Licence: MIT
#>

param([switch]$Quiet)

$ErrorActionPreference = "Continue"

$AppName     = "MultiTUNAparty"
$InstallRoot = Join-Path $env:LOCALAPPDATA $AppName
$AppDir      = Join-Path $InstallRoot "app"
$EnvDir      = Join-Path $InstallRoot "env"
$Src         = $PSScriptRoot

function Say { param([string]$Text, [string]$Colour = "Gray")
    if (-not $Quiet) { Write-Host $Text -ForegroundColor $Colour } }

if (-not (Test-Path $AppDir)) {
    Say "" ; Say "找不到已安裝的 MultiTUNAparty / MultiTUNAparty is not installed here." "Yellow"
    Say "請先執行 INSTALL.bat / Run INSTALL.bat first." "Yellow"
    exit 1
}

Say ""
Say "  ==========================================================" "Cyan"
Say "   $AppName - 更新 / Update" "Cyan"
Say "  ==========================================================" "Cyan"
Say ""

# ---------------------------------------------------------------------------
# 1. the files that change often, and are cheap to replace
# ---------------------------------------------------------------------------

$updated = 0
foreach ($f in @("launcher.py", "train_launcher.py",
                 "MultiTUNAparty.ico", "MultiTUNAparty_Training.ico")) {
    $from = Join-Path $Src $f
    if (Test-Path $from) {
        Copy-Item $from -Destination (Join-Path $AppDir $f) -Force
        $updated++
    }
}
Say "  $updated $(if ($updated -eq 1) {'file'} else {'files'}) updated / 個檔案已更新" "Green"

# the application source, if this copy of the installer carries a newer one
$bundled = Join-Path (Split-Path -Parent $Src) "app"
if (Test-Path $bundled) {
    $n = 0
    Get-ChildItem $bundled -File | ForEach-Object {
        Copy-Item $_.FullName -Destination (Join-Path $AppDir $_.Name) -Force
        $n++
    }
    $bv = Join-Path $AppDir "model_multitask_boundaryversion.py"
    if (Test-Path $bv) { Copy-Item $bv -Destination (Join-Path $AppDir "model_multitask.py") -Force }
    Say "  $n application files refreshed / 個程式檔已更新" "Green"
}

# ---------------------------------------------------------------------------
# 2. the user's own folder
# ---------------------------------------------------------------------------

$workspace = ""
$py = Join-Path $EnvDir "Scripts\python.exe"
if (Test-Path $py) {
    $out = & $py (Join-Path $AppDir "train_launcher.py") "--prepare-only" 2>&1
    $line = ($out | Select-Object -Last 1 | Out-String).Trim()
    if ($line -and (Test-Path $line)) { $workspace = $line }
}
if ($workspace) { Say "  你的資料夾 / your folder: $workspace" "Green" }

# ---------------------------------------------------------------------------
# 3. shortcuts, so the new artwork actually appears
# ---------------------------------------------------------------------------

function New-Shortcut {
    param([string]$Path, [string]$Target, [string]$Arguments,
          [string]$WorkDir, [string]$Description, [string]$Icon = "")
    try {
        $ws = New-Object -ComObject WScript.Shell
        $sc = $ws.CreateShortcut($Path)
        $sc.TargetPath       = $Target
        if ($Arguments) { $sc.Arguments = $Arguments }
        $sc.WorkingDirectory = $WorkDir
        $sc.Description      = $Description
        if ($Icon -and (Test-Path $Icon)) { $sc.IconLocation = $Icon }
        $sc.Save()
        return $true
    } catch { return $false }
}

$desktop   = [Environment]::GetFolderPath("Desktop")
$startMenu = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\$AppName"
New-Item -ItemType Directory -Force -Path $startMenu | Out-Null

$icon      = Join-Path $AppDir "MultiTUNAparty.ico"
$iconTrain = Join-Path $AppDir "MultiTUNAparty_Training.ico"
if (-not (Test-Path $iconTrain)) { $iconTrain = $icon }

$pythonw  = Join-Path $EnvDir "Scripts\pythonw.exe"
$lnkArgs  = '"' + (Join-Path $AppDir "launcher.py") + '"'
$runTrain = Join-Path $InstallRoot "MultiTUNAparty_Training.bat"
$desc     = "Identify and measure cells, roots and fungal structures"

$made = 0
if (Test-Path $pythonw) {
    if (New-Shortcut (Join-Path $desktop   "MultiTUNAparty.lnk") $pythonw $lnkArgs $AppDir $desc $icon) { $made++ }
    if (New-Shortcut (Join-Path $startMenu "MultiTUNAparty.lnk") $pythonw $lnkArgs $AppDir $desc $icon) { $made++ }
}
if (Test-Path $runTrain) {
    if (New-Shortcut (Join-Path $startMenu "MultiTUNAparty Training.lnk") $runTrain "" $AppDir "Train your own model" $iconTrain) { $made++ }
    if (New-Shortcut (Join-Path $desktop   "MultiTUNAparty Training.lnk") $runTrain "" $AppDir "Train your own model" $iconTrain) { $made++ }
}
if ($workspace -and (Test-Path $workspace)) {
    if (New-Shortcut (Join-Path $startMenu "MultiTUNAparty Data Folder.lnk") $workspace "" $workspace "Your own images and training results" "") { $made++ }
}
Say "  $made shortcuts rebuilt / 個捷徑已重建" "Green"

# Explorer caches shortcut icons by file path, and the path has not changed --
# only the picture inside it. Without this the Desktop keeps showing the old
# icon until the user logs out, which reads as "the update did not work".
try { Start-Process -FilePath "ie4uinit.exe" -ArgumentList "-show" -WindowStyle Hidden -ErrorAction SilentlyContinue } catch { }
Start-Sleep -Milliseconds 400

Say ""
Say "  ==========================================================" "Green"
Say "   完成 / Done" "Green"
Say "  ==========================================================" "Green"
Say ""
Say "   桌面上的兩個圖示現在是不一樣的魚：" "White"
Say "     MultiTUNAparty          戴博士帽的鮪魚 / tuna in a doctoral cap" "Gray"
Say "     MultiTUNAparty Training 小朋友鮪魚 / young tuna" "Gray"
Say ""
if ($workspace) {
    Say "   訓練用的資料夾 / the folder training reads from:" "White"
    Say "     $workspace\data" "Cyan"
    Say ""
}
exit 0
