"""
train_launcher.py -- MultiTUNAparty

Starts the training interface, and makes it usable by a person who does not
write code.

Three things it fixes, without editing app_train_en.py:

1. The Data Path box shipped with the default "data/", which is resolved
   against the working directory. After installation that directory is inside
   %LOCALAPPDATA%, where no data folder exists, so the first thing a new user
   sees is "Data path does not exist: data". This launcher creates a real
   folder under Documents, with the required train/val subfolders already in
   place, and fills the box with its full path.

2. Training used to write its results next to the program in %LOCALAPPDATA%,
   where nobody would ever find them. The working directory is now the user's
   own workspace folder, so outputs/ lands beside their images.

3. app_train_en.py only imports gradio, so the interface opened happily even
   when the packages the actual training run needs were missing. Pressing
   "Start Training" then spawned a subprocess that died on an ImportError while
   the interface reported "Training has started". The dependency check below
   makes that failure visible before it can happen.

Author: Shitephen Wang
Licence: MIT
"""

from __future__ import annotations

import importlib
import json
import os
import runpy
import subprocess
import sys
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
INSTALL_ROOT = APP_DIR.parent
CONFIG = INSTALL_ROOT / "config.json"

sys.path.insert(0, str(APP_DIR))

# The console window runs chcp 65001, but do not depend on it: without this a
# single Chinese character in a status line would raise UnicodeEncodeError and
# take the whole interface down with it.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

# (import name, pip name, what breaks without it)
REQUIRED = [
    ("gradio", "gradio", "the training interface itself"),
    ("albumentations", "albumentations", "image augmentation during training"),
    ("torch", "torch", "the model"),
    ("cv2", "opencv-python", "image loading"),
    ("yaml", "pyyaml", "the training configuration"),
]

IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp"}


# ---------------------------------------------------------------------------
# where the user's own material lives
# ---------------------------------------------------------------------------

def workspace_dir() -> Path:
    """A folder the user can actually find, under Documents."""
    env = os.environ.get("MULTITUNAPARTY_WORKSPACE")
    if env:
        return Path(env)
    for base in (Path.home() / "Documents", Path.home()):
        if base.is_dir():
            return base / "MultiTUNAparty"
    return INSTALL_ROOT / "workspace"


WORKSPACE = workspace_dir()
DATA_DIR = WORKSPACE / "data"

DATA_README = """\
把你自己的影像放進這裡 / Put your own images here
==================================================

  data\\
    train\\            <- 用來訓練的影像 / images used for training
      other\\
        images\\       <- 影像 (.jpg .png .tif)
        masks\\        <- 遮罩 (.png)，檔名要和影像一模一樣
    val\\              <- 用來檢查成效的影像 / images used to check progress
      other\\
        images\\
        masks\\

遮罩是黑白兩色的圖：白色 = 你要找的東西，黑色 = 背景。
A mask is a black-and-white image: white is the thing you want to find,
black is everything else. Each mask must have exactly the same file name
as its image (apart from the .png ending).

大概放多少 / How many:
  train 20-60 張、val 5-15 張就能看到效果。越多越好。
  20-60 images in train and 5-15 in val is enough to see a result.

資料夾名字是有意義的 / The folder name matters:
  cell\\   植物細胞      plant cells
  blood\\  血球          blood cells
  other\\  其他任何標的  anything else: roots, fungal traps, hyphae...

  訓練新的標的時用 other\\ 就好，上面已經幫你建好了。
  Use other\\ for a new target; it has been created for you already.

訓練完成後 / When training finishes:
  新模型在 outputs\\models\\best_model.pth
  要使用它：打開 MultiTUNAparty，到 Model Management 分頁，
  按 Browse 選這個檔案，再按 Load Model，任務類型選 Other。

  The new model is outputs\\models\\best_model.pth. To use it, open
  MultiTUNAparty, go to Model Management, Browse to that file, click
  Load Model, and choose the Other task type.
"""


def prepare_workspace() -> bool:
    """Create the folder layout the training interface expects.

    Returns True when the data folders contain no images yet, i.e. this looks
    like a first run and the user still has to put something in.
    """
    for split in ("train", "val"):
        for sub in ("images", "masks"):
            (DATA_DIR / split / "other" / sub).mkdir(parents=True, exist_ok=True)
    (WORKSPACE / "outputs" / "models").mkdir(parents=True, exist_ok=True)

    readme = DATA_DIR / "放影像的說明_How_to_add_data.txt"
    if not readme.exists():
        try:
            readme.write_text(DATA_README, encoding="utf-8")
        except Exception:
            pass

    n = sum(1 for p in DATA_DIR.rglob("*")
            if p.is_file() and p.suffix.lower() in IMAGE_SUFFIXES)
    return n == 0


def installed_model() -> str:
    """The checkpoint the installer put in place, if there is one."""
    env = os.environ.get("MULTITUNAPARTY_MODEL")
    if env and Path(env).is_file():
        return env
    if CONFIG.is_file():
        try:
            p = json.loads(CONFIG.read_text(encoding="utf-8")).get("model_path", "")
            if p and Path(p).is_file():
                return p
        except Exception:
            pass
    for cand in (INSTALL_ROOT / "models" / "best_model.pth",
                 APP_DIR / "outputs" / "models" / "best_model.pth",
                 APP_DIR / "best_model.pth"):
        if cand.is_file():
            return str(cand)
    return ""


# ---------------------------------------------------------------------------
# make the interface open with sensible values already filled in
# ---------------------------------------------------------------------------

PATCH_LABELS = ('label="Data Path"', 'label="Use Pre-trained Model"')


def patch_defaults(model_path: str) -> bool:
    """Replace two hard-coded defaults in the Gradio interface.

    Matched on the component's label, and applied by shadowing gr.Textbox and
    gr.Checkbox with plain functions. The gradio namespace is what user code
    calls; gradio's own internals reference the classes directly, so nothing
    inside the library is affected.

    Returns False if app_train_en.py no longer carries the labels this matches
    on -- in which case the interface still opens, just with its original
    defaults, and the caller says so instead of leaving the user to rediscover
    the confusing error message.
    """
    import gradio as gr

    base_text = gr.Textbox
    base_check = gr.Checkbox
    data_str = str(DATA_DIR)

    def Textbox(*a, **kw):
        label = kw.get("label")
        if label == "Data Path":
            kw["value"] = data_str
            kw["info"] = ("Your images live here: train\\other\\images and "
                          "val\\other\\images, with matching masks in the "
                          "masks folders next to them.")
        elif label == "Pre-trained Model Path" and model_path:
            kw["value"] = model_path
        return base_text(*a, **kw)

    def Checkbox(*a, **kw):
        if kw.get("label") == "Use Pre-trained Model" and model_path:
            # Starting from the shipped weights is the only thing that works
            # on a lab-sized dataset; from scratch would need thousands of
            # images.
            kw["value"] = True
        return base_check(*a, **kw)

    gr.Textbox = Textbox
    gr.Checkbox = Checkbox

    try:
        src = (APP_DIR / "app_train_en.py").read_text(encoding="utf-8")
    except Exception:
        return True
    return all(lbl in src for lbl in PATCH_LABELS)


def patch_subprocess() -> None:
    """Let the training run start from the user's workspace.

    app_train_en.py launches 'train_multitask_optimized.py' by bare file name,
    which only works when the working directory is the program folder. The
    working directory is the user's workspace instead, so that outputs\\ lands
    beside their images -- so rewrite that one argument to a full path. Python
    puts a script's own folder at the front of sys.path, so the training
    script's sibling imports keep working.
    """
    real_popen = subprocess.Popen
    target = "train_multitask_optimized.py"

    def Popen(args, *a, **kw):
        if isinstance(args, (list, tuple)) and any(
                isinstance(x, str) and x.endswith(target) for x in args):
            args = list(args)
            for i, item in enumerate(args):
                if isinstance(item, str) and item.endswith(target) \
                        and not Path(item).is_absolute():
                    local = APP_DIR / Path(item).name
                    if local.is_file():
                        args[i] = str(local)
            kw.setdefault("cwd", str(WORKSPACE))
        return real_popen(args, *a, **kw)

    subprocess.Popen = Popen


# ---------------------------------------------------------------------------
# dependency check
# ---------------------------------------------------------------------------

def missing_packages() -> list[tuple[str, str, str]]:
    out = []
    for mod, pip_name, purpose in REQUIRED:
        try:
            importlib.import_module(mod)
        except Exception:
            out.append((mod, pip_name, purpose))
    return out


def report(missing: list[tuple[str, str, str]]) -> None:
    py = sys.executable
    names = " ".join(p for _, p, _ in missing)

    lines = [
        "",
        "=" * 66,
        "  訓練介面無法啟動 / The training interface cannot start",
        "=" * 66,
        "",
        "  以下套件沒有安裝 / These packages are missing:",
        "",
    ]
    for mod, pip_name, purpose in missing:
        lines.append(f"    - {pip_name:<20} ({purpose})")
    lines += [
        "",
        "  辨識與量測功能不受影響，仍然可以正常使用。",
        "  Prediction and measurement are unaffected and still work.",
        "",
        "  要修復，請複製下面這一行貼到命令提示字元執行：",
        "  To fix, copy this line into a Command Prompt and run it:",
        "",
        f'    "{py}" -m pip install {names}',
        "",
        "  若出現「Microsoft Visual C++ 14.0 or greater is required」，改用：",
        '  If it says a C++ compiler is required, use this instead:',
        "",
        f'    "{py}" -m pip install --only-binary=:all: {names}',
        "",
        "=" * 66,
        "",
    ]
    text = "\n".join(lines)
    print(text)
    try:
        (INSTALL_ROOT / "training_error.txt").write_text(text, encoding="utf-8")
    except Exception:
        pass
    try:
        import tkinter as tk
        from tkinter import messagebox
        r = tk.Tk(); r.withdraw()
        messagebox.showwarning(
            "MultiTUNAparty",
            "訓練介面無法啟動，缺少套件：\n  "
            + "\n  ".join(p for _, p, _ in missing)
            + "\n\n辨識與量測功能不受影響。\n\n"
              "修復指令已顯示在後面的黑色視窗裡，也存到：\n"
            + str(INSTALL_ROOT / "training_error.txt")
            + "\n\n---\n\nThe training interface cannot start; packages are "
              "missing. Prediction and measurement still work. The fix command "
              "is in the console window behind this one.")
        r.destroy()
    except Exception:
        pass


# ---------------------------------------------------------------------------

def announce(empty: bool, model_path: str) -> None:
    bar = "=" * 66
    print(bar)
    print("  MultiTUNAparty - 訓練 / Training")
    print(bar)
    print()
    print("  你的資料夾 / Your folder:")
    print(f"    {WORKSPACE}")
    print()
    print("  影像放這裡 / Images go here:")
    print(f"    {DATA_DIR / 'train' / 'other' / 'images'}")
    print(f"    {DATA_DIR / 'train' / 'other' / 'masks'}")
    print(f"    {DATA_DIR / 'val' / 'other' / 'images'}")
    print(f"    {DATA_DIR / 'val' / 'other' / 'masks'}")
    print()
    print("  訓練結果會存到 / Results are saved to:")
    print(f"    {WORKSPACE / 'outputs' / 'models' / 'best_model.pth'}")
    print()
    if model_path:
        print("  會從已安裝的模型接著訓練（在介面上可以取消）")
        print("  Training continues from the installed model (you can turn")
        print("  this off in the interface):")
        print(f"    {model_path}")
        print()
    if empty:
        print("  資料夾目前是空的。請先把影像和遮罩放進去，再按")
        print("  Check Data Structure。說明在資料夾裡的說明檔。")
        print("  The folders are empty. Put your images and masks in first,")
        print("  then press Check Data Structure. There is a text file in the")
        print("  folder explaining the layout.")
        print()
    print(bar)
    print()


def open_folder(path: Path) -> None:
    try:
        os.startfile(str(path))  # type: ignore[attr-defined]
    except Exception:
        pass


def main() -> int:
    # setup.ps1 calls this during installation so the folders exist before the
    # user opens anything. Needs nothing but the standard library.
    #
    # --explain adds a bilingual summary for FIX_TRAINING_DATA_PATH.bat, which
    # is deliberately ASCII-only: cmd.exe reads a .bat in the OEM code page and
    # would mangle Chinese text, whereas Python controls its own encoding.
    if "--prepare-only" in sys.argv:
        empty = prepare_workspace()
        if "--explain" in sys.argv:
            announce(empty, installed_model())
        else:
            print(str(WORKSPACE))  # setup.ps1 reads the last line
        return 0

    missing = missing_packages()
    if missing:
        report(missing)
        input("按 Enter 關閉 / Press Enter to close: ")
        return 1

    empty = prepare_workspace()
    model_path = installed_model()

    os.chdir(WORKSPACE)
    patched = patch_defaults(model_path)
    patch_subprocess()

    announce(empty, model_path)
    if not patched:
        print("  注意：Data Path 欄位可能仍是預設的 data/，請自己貼上面那個路徑。")
        print("  Note: the Data Path box may still say data/ - paste the path")
        print("  above into it yourself.")
        print()
    if empty:
        open_folder(DATA_DIR)

    print("啟動訓練介面 / Starting the training interface...")
    print("瀏覽器會自動開啟；若沒有，請手動前往 / If your browser does not open, go to:")
    print("    http://localhost:7860")
    print()
    print("這個視窗要一直開著 / Keep this window open.")
    print()
    runpy.run_path(str(APP_DIR / "app_train_en.py"), run_name="__main__")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit(0)
    except Exception as exc:
        import traceback
        traceback.print_exc()
        try:
            (INSTALL_ROOT / "training_error.txt").write_text(
                traceback.format_exc(), encoding="utf-8")
        except Exception:
            pass
        input("\n按 Enter 關閉 / Press Enter to close: ")
        sys.exit(1)
