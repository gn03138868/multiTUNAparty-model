#!/usr/bin/env python3
"""
make_icons.py -- MultiTUNAparty application icons.

Draws two tuna in the same flat, heavy-outlined style as the rest of the
project's artwork, and packs each into a multi-resolution Windows .ico:

  MultiTUNAparty.ico           an adult tuna in a doctoral cap
  MultiTUNAparty_Training.ico  a young tuna, for the training interface

The body outline is generated rather than drawn by hand. Hand-placed beziers
kept producing a round cartoon fish; a tuna is a fusiform solid whose depth
peaks about a third of the way back from the snout and tapers to a thin tail
stock, and that is a two-line function. Generating it also means every fin, the
cap and the eye can be *placed against the outline* rather than guessed at,
which is what stops them looking like separate shapes floating nearby -- the
first two attempts at this icon both failed exactly there.

Fins are drawn before the body so they emerge from behind it.

Every icon carries two drawings. Below 48 px the fine detail -- finlets,
pectoral fin, the tassel -- turns into grey mush, so the small sizes get a
simplified drawing with heavier strokes and nothing under about four pixels
across. Windows picks whichever size it needs and gets the right drawing with
it.

Author: Shitephen Wang   Licence: MIT
"""

from __future__ import annotations

import io
import pathlib

import cairosvg
from PIL import Image

OUT = pathlib.Path(__file__).resolve().parent

# palette -- carried over from the project's existing artwork
INK       = "#15212B"   # outline
PAPER     = "#F7F4EC"   # background tile, adult
PAPER_KID = "#E1F0EF"   # background tile, young fish
BLUE      = "#1A6CA8"   # adult body
BLUE_DK   = "#123F63"   # adult fins
CYAN      = "#45B2DD"   # young body
CYAN_DK   = "#227A9E"   # young fins
BELLY     = "#AECFE2"   # NOT white: against a cream tile a white
                        # belly matches the background and the fish
                        # looks cut in half
AMBER     = "#F0A81C"   # finlets
TEAL      = "#0E9B70"   # pectoral fin
GOLD      = "#F2C53D"   # tassel
CAP       = "#1B2733"   # mortarboard
BELLY_KID = "#A8D8E8"
BLUSH     = "#F09C9C"

SIZES = [16, 24, 32, 48, 64, 128, 256]
SIMPLIFY_BELOW = 48


# ---------------------------------------------------------------------------
# the shape of a tuna
# ---------------------------------------------------------------------------

class Fish:
    """A fusiform body, parameterised from snout (t=0) to tail stock (t=1)."""

    def __init__(self, snout: float, peduncle: float, mid: float,
                 depth: float, stock: float = 0.15, peak: float = 0.42,
                 belly: float = 1.0):
        self.snout, self.ped, self.mid = snout, peduncle, mid
        self.depth, self.stock, self.peak = depth, stock, peak
        self.belly_ratio = belly

    def x(self, t: float) -> float:
        return self.snout - t * (self.snout - self.ped)

    def half(self, t: float) -> float:
        """Half-depth at t: a peak near the shoulders, a floor at the stock."""
        t = min(max(t, 0.0), 1.0)
        a = self.peak
        k = (t / a) ** 0.62 if t < a else ((1 - t) / (1 - a)) ** 0.75
        return self.depth * (self.stock + (1 - self.stock) * k)

    def top(self, t: float) -> tuple[float, float]:
        return self.x(t), self.mid - self.half(t)

    def bottom(self, t: float) -> tuple[float, float]:
        return self.x(t), self.mid + self.half(t) * self.belly_ratio

    def outline(self, n: int = 120) -> str:
        pts = [self.top(i / n) for i in range(n + 1)]
        pts += [self.bottom(i / n) for i in range(n, -1, -1)]
        return (f"M{pts[0][0]:.2f} {pts[0][1]:.2f} "
                + " ".join(f"L{x:.2f} {y:.2f}" for x, y in pts[1:]) + " Z")

    def belly(self, t0: float, t1: float, share: float = 0.40,
              n: int = 64) -> str:
        """The silver underside.

        Bounded below by the outline and above by a curve that is a scaled copy
        of the outline itself, so the boundary bends the way the fish does. A
        straight cut, which is what this had first, reads as a waterline drawn
        across the animal; a boundary parallel to the belly reads as a wedge.
        Taking a constant *share* of the local depth avoids both.
        """
        lo, hi = [], []
        for i in range(n + 1):
            t = t0 + (t1 - t0) * i / n
            x, y = self.bottom(t)
            lo.append((x, y))
            hi.append((x, y - self.half(t) * self.belly_ratio * share * 2))
        pts = lo + hi[::-1]
        return (f"M{pts[0][0]:.2f} {pts[0][1]:.2f} "
                + " ".join(f"L{x:.2f} {y:.2f}" for x, y in pts[1:]) + " Z")


# ---------------------------------------------------------------------------
# parts, all positioned against the outline
# ---------------------------------------------------------------------------

def finlets(fish: Fish, ts: list[float], up: bool, size: float,
            width: float = 1.8) -> str:
    """The row of little keels along a tuna's tail stock."""
    out = []
    for t in ts:
        x, y = fish.top(t) if up else fish.bottom(t)
        d = -size if up else size
        out.append(
            f'<path d="M{x + size * 0.65:.1f} {y:.1f} '
            f'L{x - size * 0.55:.1f} {y + d:.1f} '
            f'L{x - size * 1.0:.1f} {y + d * 0.1:.1f} Z" '
            f'fill="{AMBER}" stroke="{INK}" stroke-width="{width}"/>')
    return "".join(out)


def crescent_tail(fish: Fish, reach: float, spread: float, fork: float,
                  colour: str, width: float) -> str:
    """The lunate caudal fin: two swept lobes meeting in a shallow fork."""
    px, ty = fish.top(1.0)
    _, by = fish.bottom(1.0)
    m, tip = fish.mid, px - reach
    inner = px - fork
    return (
        f'<path d="M{px:.1f} {ty:.1f} '
        f'C{px - reach * 0.30:.1f} {ty - spread * 0.30:.1f} '
        f'{tip + reach * 0.22:.1f} {m - spread * 0.72:.1f} '
        f'{tip:.1f} {m - spread:.1f} '
        f'C{tip + reach * 0.42:.1f} {m - spread * 0.62:.1f} '
        f'{inner - fork * 0.5:.1f} {m - spread * 0.24:.1f} '
        f'{inner:.1f} {m:.1f} '
        f'C{inner - fork * 0.5:.1f} {m + spread * 0.24:.1f} '
        f'{tip + reach * 0.42:.1f} {m + spread * 0.62:.1f} '
        f'{tip:.1f} {m + spread:.1f} '
        f'C{tip + reach * 0.22:.1f} {m + spread * 0.72:.1f} '
        f'{px - reach * 0.30:.1f} {by + spread * 0.30:.1f} '
        f'{px:.1f} {by:.1f} Z" '
        f'fill="{colour}" stroke="{INK}" stroke-width="{width}"/>')


def dorsal(fish: Fish, t0: float, t1: float, rise: float, lean: float,
           colour: str, width: float) -> str:
    """A triangular first dorsal, its base sitting on the fish's own back."""
    x0, y0 = fish.top(t0)
    x1, y1 = fish.top(t1)
    ax = x0 + (x1 - x0) * lean
    ay = min(y0, y1) - rise
    return (f'<path d="M{x0:.1f} {y0 + 1:.1f} '
            f'C{x0 - 1:.1f} {y0 - rise * 0.45:.1f} '
            f'{ax + 3.5:.1f} {ay + rise * 0.30:.1f} {ax:.1f} {ay:.1f} '
            f'C{ax - 1.5:.1f} {ay + rise * 0.5:.1f} '
            f'{x1 + 1.5:.1f} {y1 - rise * 0.25:.1f} {x1:.1f} {y1 + 1:.1f} Z" '
            f'fill="{colour}" stroke="{INK}" stroke-width="{width}"/>')


def mortarboard(fish: Fish, t: float, half_w: float, half_h: float,
                width: float, tassel: bool, tilt: float = 0.0) -> str:
    """A doctoral cap worn on the head, not hovering above it.

    The crown's base is placed on the point of the outline at `t`, so the cap
    always makes contact with the fish however the body is proportioned.
    """
    hx, hy = fish.top(t)
    base = hy + 1.5                       # a little into the head
    crown_h = half_h * 1.5
    cy = base - crown_h                   # the board rests on the crown
    lift = half_w * tilt                  # a slight rakish tilt

    crown = (f'<path d="M{hx - half_w * 0.44:.1f} {base:.1f} '
             f'C{hx - half_w * 0.40:.1f} {base - crown_h * 1.7:.1f} '
             f'{hx + half_w * 0.40:.1f} {base - crown_h * 1.7:.1f} '
             f'{hx + half_w * 0.44:.1f} {base - 0.5:.1f} '
             f'C{hx + half_w * 0.2:.1f} {base + 2.5:.1f} '
             f'{hx - half_w * 0.2:.1f} {base + 2.5:.1f} '
             f'{hx - half_w * 0.44:.1f} {base:.1f} Z" '
             f'fill="{CAP}" stroke="{INK}" stroke-width="{width * 0.92:.1f}"/>')

    lx, ly = hx - half_w, cy + lift
    rx, ry = hx + half_w, cy - lift
    board = (f'<path d="M{lx:.1f} {ly:.1f} L{hx:.1f} {cy - half_h - lift * 0.2:.1f} '
             f'L{rx:.1f} {ry:.1f} L{hx:.1f} {cy + half_h - lift * 0.2:.1f} Z" '
             f'fill="{CAP}" stroke="{INK}" stroke-width="{width}"/>')
    if not tassel:
        return crown + board

    # A cord that hangs nearly straight down, ending in a fat tuft. Both are
    # strokes with round caps, dark under gold, so no joint can open up at
    # small sizes. Earlier versions bowed the cord outwards and it read as a
    # bag handle rather than a tassel.
    def hang(colour: str, thin: float, fat: float) -> str:
        return (f'<path d="M{rx:.1f} {ry:.1f} C{rx + 2.6:.1f} {ry + 3:.1f} '
                f'{rx + 2.8:.1f} {ry + 6:.1f} {rx + 2.2:.1f} {ry + 8.8:.1f}" '
                f'fill="none" stroke="{colour}" stroke-width="{thin:.1f}"/>'
                f'<path d="M{rx + 2.2:.1f} {ry + 9.3:.1f} '
                f'L{rx + 1.8:.1f} {ry + 12.8:.1f}" '
                f'fill="none" stroke="{colour}" stroke-width="{fat:.1f}"/>')
    return (crown + board
            + hang(INK, width * 1.55, width * 2.5)
            + hang(GOLD, width * 0.62, width * 1.45))


def eye(fish: Fish, t: float, r: float, width: float, sparkle: bool = False,
        raise_by: float = 0.30) -> str:
    """An eye set high on the head, guaranteed to sit inside the outline."""
    x, _ = fish.top(t)
    back = fish.mid - fish.half(t)
    y = back + max(r + width * 0.6, fish.half(t) * raise_by + r * 0.4)
    out = (f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{r:.1f}" fill="#FFFFFF" '
           f'stroke="{INK}" stroke-width="{width}"/>'
           f'<circle cx="{x + r * 0.28:.1f}" cy="{y + r * 0.08:.1f}" '
           f'r="{r * 0.48:.1f}" fill="{INK}"/>')
    if sparkle:
        out += (f'<circle cx="{x + r * 0.42:.1f}" cy="{y - r * 0.30:.1f}" '
                f'r="{r * 0.20:.1f}" fill="#FFFFFF"/>')
    return out


def tile(colour: str) -> str:
    return (f'<rect x="2.5" y="2.5" width="95" height="95" rx="22" ry="22" '
            f'fill="{colour}" stroke="{INK}" stroke-width="3.4"/>')


def svg(body: str, paper: str) -> str:
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" '
            'width="100" height="100">'
            '<g stroke-linecap="round" stroke-linejoin="round">'
            + tile(paper) + body + '</g></svg>')


# ---------------------------------------------------------------------------
# the two fish
# ---------------------------------------------------------------------------

def adult(small: bool) -> str:
    """Grown-up tuna, doctoral cap. Deliberately spare: at 32 px an icon can
    carry a silhouette, one accent and one prop, and nothing else survives."""
    w = 4.4 if small else 3.4
    f = 3.8 if small else 3.0
    fish = Fish(snout=81, peduncle=34, mid=60, depth=17.5, stock=0.17, peak=0.40)

    p = [crescent_tail(fish, reach=19, spread=20, fork=8,
                       colour=BLUE_DK, width=f)]
    p.append(dorsal(fish, 0.40, 0.64, rise=12 if small else 11, lean=0.70,
                    colour=BLUE_DK, width=f))
    if not small:
        p.append(finlets(fish, [0.74, 0.87], True, 4.0))
    p.append(f'<path d="{fish.outline()}" fill="{BLUE}" stroke="{INK}" '
             f'stroke-width="{w}"/>')
    if not small:
        p.append(f'<path d="{fish.belly(0.015, 0.985, 0.30)}" fill="{BELLY}" '
                 f'stroke="none"/>')
    # The board is tilted forward so the tassel hangs down beside the head
    # instead of trailing off into empty space past the snout, which is what
    # made it read as a bag handle.
    p.append(mortarboard(fish, 0.21, half_w=13 if small else 12,
                         half_h=7.0 if small else 6.6,
                         width=3.9 if small else 3.1,
                         tassel=not small, tilt=-0.16))
    p.append(eye(fish, 0.14, 6.6 if small else 5.6, 3.4 if small else 2.7))
    return "<g>" + "".join(p) + "</g>"


def young(small: bool) -> str:
    """The same fish as a child: shorter, rounder, and mostly eye."""
    w = 4.4 if small else 3.4
    f = 3.8 if small else 3.0
    fish = Fish(snout=83, peduncle=39, mid=56, depth=20.0, stock=0.20,
                peak=0.48, belly=1.06)

    p = [crescent_tail(fish, reach=18, spread=17, fork=6.5,
                       colour=CYAN_DK, width=f)]
    p.append(dorsal(fish, 0.36, 0.56, rise=10 if small else 9.5, lean=0.72,
                    colour=CYAN_DK, width=f))
    if not small:
        p.append(finlets(fish, [0.80], True, 4.0))
    p.append(f'<path d="{fish.outline()}" fill="{CYAN}" stroke="{INK}" '
             f'stroke-width="{w}"/>')
    if not small:
        p.append(f'<path d="{fish.belly(0.015, 0.985, 0.30)}" fill="{BELLY_KID}" '
                 f'stroke="none"/>')
        p.append(f'<ellipse cx="62" cy="60" rx="4.8" ry="3.3" '
                 f'fill="{BLUSH}" opacity="0.9"/>')
        p.append('<path d="M82 61 C79.5 64.5 78 65.5 75.5 64.5" fill="none" '
                 f'stroke="{INK}" stroke-width="2.6"/>')
    p.append(eye(fish, 0.235, 9.4 if small else 8.6, 3.5 if small else 2.9,
                 sparkle=True, raise_by=0.16))
    return "<g>" + "".join(p) + "</g>"


DRAWINGS = {
    "MultiTUNAparty":          (adult(False), adult(True), PAPER),
    "MultiTUNAparty_Training": (young(False), young(True), PAPER_KID),
}


def render(markup: str, px: int) -> Image.Image:
    png = cairosvg.svg2png(bytestring=markup.encode("utf-8"),
                           output_width=px, output_height=px)
    return Image.open(io.BytesIO(png)).convert("RGBA")


def build() -> None:
    for name, (detail, small, paper) in DRAWINGS.items():
        big, tiny = svg(detail, paper), svg(small, paper)
        (OUT / f"{name}.svg").write_text(big, encoding="utf-8")
        (OUT / f"{name}_small.svg").write_text(tiny, encoding="utf-8")

        frames = [render(tiny if s < SIMPLIFY_BELOW else big, s) for s in SIZES]
        frames[-1].save(OUT / f"{name}.ico", format="ICO",
                        sizes=[(s, s) for s in SIZES],
                        append_images=frames[:-1])
        render(big, 512).save(OUT / f"{name}_preview.png")
        kb = (OUT / f"{name}.ico").stat().st_size / 1024
        print(f"  {name}.ico  {kb:6.1f} KB  {SIZES}")


if __name__ == "__main__":
    build()
    print("done")
