@echo off
title MultiTUNAparty - update an existing installation
setlocal

set "HERE=%~dp0"
if "%HERE:~-1%"=="\" set "HERE=%HERE:~0,-1%"
set "PS1=%HERE%\installer\update_existing.ps1"

echo.
echo  ==================================================================
echo   MultiTUNAparty - update
echo  ==================================================================
echo.
echo  Use this when MultiTUNAparty is ALREADY installed on this computer.
echo  It refreshes the program files, the two Desktop icons and the data
echo  folder. It takes a few seconds and does NOT reinstall Python,
echo  PyTorch or the model.
echo.
echo  If MultiTUNAparty is not installed yet, close this and run
echo  INSTALL.bat instead.
echo.

if not exist "%PS1%" (
  echo  Cannot find installer\update_existing.ps1 next to this file.
  echo  Please re-extract the whole zip rather than pulling out one file.
  echo.
  pause
  exit /b 1
)

chcp 65001 >nul 2>&1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS1%"
set "RC=%ERRORLEVEL%"

echo.
if not "%RC%"=="0" (
  echo  The update did not finish. See the messages above.
)
pause
endlocal
