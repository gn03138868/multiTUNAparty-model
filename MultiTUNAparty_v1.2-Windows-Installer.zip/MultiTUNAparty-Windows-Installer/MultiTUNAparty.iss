; MultiTUNAparty - Inno Setup script
; Builds MultiTUNAparty-Setup.exe: a familiar Next/Next/Finish wizard that
; unpacks the application and then runs the PowerShell installer, which sets up
; Python, PyTorch and the model.
;
; To build:
;   1. Install Inno Setup 6 (free): https://jrsoftware.org/isdl.php
;   2. Double-click build_installer_exe.bat, or open this file in Inno Setup and
;      press F9.
;
; The wizard itself needs no admin rights (PrivilegesRequired=lowest) so a lab
; user without an IT account can install it.

#define AppName        "MultiTUNAparty"
#define AppVersion     "1.1"
#define AppPublisher   "Shitephen Wang, National Taiwan University"
#define AppURL         "https://github.com/gn03138868/multiTUNAparty-model"
#define SourceRoot     "."

[Setup]
AppId={{7B3C1E4A-6F2D-4A11-9C3E-MULTITUNAPARTY}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#AppPublisher}
AppPublisherURL={#AppURL}
AppSupportURL={#AppURL}/issues
DefaultDirName={localappdata}\{#AppName}\payload
DefaultGroupName={#AppName}
DisableProgramGroupPage=yes
DisableDirPage=yes
PrivilegesRequired=lowest
OutputDir=dist
OutputBaseFilename=MultiTUNAparty-Setup
SetupIconFile=installer\MultiTUNAparty.ico
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
LicenseFile=LICENSE.txt
DisableWelcomePage=no
ShowLanguageDialog=auto

[Languages]
Name: "english";  MessagesFile: "compiler:Default.isl"
Name: "chinese";  MessagesFile: "compiler:Languages\ChineseTraditional.isl"

[CustomMessages]
english.PrepMsg=Setting up Python, PyTorch and the trained model.%nThis takes 15-30 minutes and needs an internet connection.%nPlease leave the window that opens next running until it says it is finished.
chinese.PrepMsg=正在安裝 Python、PyTorch 與訓練好的模型。%n這需要 15-30 分鐘與網路連線。%n請讓接下來開啟的視窗跑完，直到顯示安裝完成為止。
english.CpuTask=Install the CPU-only version (choose this if this computer has no NVIDIA graphics card)
chinese.CpuTask=安裝 CPU 版本（這台電腦沒有 NVIDIA 顯示卡時請勾選）
english.DeskTask=Create a shortcut on the Desktop
chinese.DeskTask=在桌面建立捷徑

[Tasks]
Name: "desktopicon"; Description: "{cm:DeskTask}"; GroupDescription: "{cm:AdditionalIcons}"
Name: "cpuonly";     Description: "{cm:CpuTask}";  Flags: unchecked

[Files]
; the application itself, shipped inside the installer so no checkout is needed
Source: "app\*";                                DestDir: "{app}\app"; Flags: ignoreversion recursesubdirs
; the installer machinery
Source: "installer\*";                          DestDir: "{app}\installer"; Flags: ignoreversion recursesubdirs
; optional: drop best_model.pth beside this .iss to ship the weights inside the
; installer instead of downloading them (adds ~500 MB to the .exe)
Source: "best_model.pth";                       DestDir: "{app}"; Flags: ignoreversion skipifsourcedoesntexist
Source: "README_INSTALL.txt";                   DestDir: "{app}"; Flags: ignoreversion isreadme skipifsourcedoesntexist

[Run]
; the heavy lifting: Python + PyTorch + model, with a visible progress window
Filename: "powershell.exe"; \
  Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\installer\setup.ps1"" -SourceDir ""{app}"""; \
  StatusMsg: "{cm:PrepMsg}"; Flags: waituntilterminated; Tasks: not cpuonly
Filename: "powershell.exe"; \
  Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\installer\setup.ps1"" -SourceDir ""{app}"" -CpuOnly"; \
  StatusMsg: "{cm:PrepMsg}"; Flags: waituntilterminated; Tasks: cpuonly

[Icons]
; setup.ps1 creates the working shortcuts; these are the wizard's own entries
Name: "{group}\{#AppName}"; Filename: "{localappdata}\{#AppName}\MultiTUNAparty.bat"; \
  IconFilename: "{app}\installer\MultiTUNAparty.ico"
Name: "{group}\{#AppName} Training"; Filename: "{localappdata}\{#AppName}\MultiTUNAparty_Training.bat"; \
  IconFilename: "{app}\installer\MultiTUNAparty_Training.ico"
Name: "{autodesktop}\{#AppName}"; Filename: "{localappdata}\{#AppName}\MultiTUNAparty.bat"; \
  IconFilename: "{app}\installer\MultiTUNAparty.ico"; Tasks: desktopicon

[UninstallDelete]
Type: filesandordirs; Name: "{localappdata}\{#AppName}"

[Code]
function InitializeSetup(): Boolean;
var
  FreeMB: Cardinal;
  TotalMB: Cardinal;
begin
  Result := True;
  if GetSpaceOnDisk(ExpandConstant('{localappdata}'), True, FreeMB, TotalMB) then
  begin
    if FreeMB < 8000 then
    begin
      if MsgBox('磁碟空間可能不足（需要約 8 GB）。仍要繼續嗎？' + #13#10 +
                'Disk space may be insufficient (about 8 GB needed). Continue anyway?',
                mbConfirmation, MB_YESNO) = IDNO then
        Result := False;
    end;
  end;
end;
