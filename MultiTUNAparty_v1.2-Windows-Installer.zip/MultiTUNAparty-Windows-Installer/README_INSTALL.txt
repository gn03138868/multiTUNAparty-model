====================================================================
  MultiTUNAparty  —  安裝說明 / Installation
  細胞、根、真菌影像的辨識與量化
  Identify and measure cells, roots and fungal structures
====================================================================


怎麼安裝 / HOW TO INSTALL
--------------------------------------------------------------------

  用滑鼠左鍵點兩下：   INSTALL.bat

  Double-click:        INSTALL.bat

  就這樣。不需要輸入任何指令，不需要系統管理員密碼。
  That is all. No commands to type, no administrator password.

  安裝過程會自己做完這些事：
  The installer does all of this by itself:

    1. 檢查磁碟空間
    2. 如果電腦沒有 Python，自動下載安裝
    3. 建立一個獨立的執行環境（不會影響電腦上其他軟體）
    4. 偵測顯示卡，挑選正確的 PyTorch 版本
    5. 安裝需要的套件
    6. 安裝程式檔案
    7. 準備訓練好的模型
    8. 在桌面建立圖示，並測試整個安裝

  需要 15–30 分鐘和約 8 GB 磁碟空間，過程中需要網路。
  Takes 15–30 minutes and about 8 GB of disk space; needs internet.

  如果 Windows 跳出「已保護您的電腦」的藍色視窗，請點
  「其他資訊」→「仍要執行」。這是因為這個檔案沒有付費簽章。
  If Windows shows a blue "Windows protected your PC" box, click
  "More info" then "Run anyway". It appears because the file is not
  code-signed.


怎麼使用 / HOW TO USE
--------------------------------------------------------------------

  安裝完成後，桌面上會出現一個圖示：MultiTUNAparty

  點兩下打開。模型會自動載入，不用做任何設定。

  After installing, a MultiTUNAparty icon appears on your Desktop.
  Double-click it. The model loads by itself; nothing to configure.

  桌面上會有兩隻魚，別搞混 / Two fish on the Desktop, do not mix them up:

    戴博士帽的鮪魚   MultiTUNAparty            辨識與量測（平常用這個）
    小朋友鮪魚       MultiTUNAparty Training   訓練自己的模型

    tuna in a doctoral cap -> predict and measure (the everyday one)
    young tuna             -> train a model of your own

  視窗上有五個分頁 / The window has five tabs:

    Model Management       模型管理（已自動載入，通常不用碰）
    Single Prediction      單張影像辨識
    Morphological Analysis 形態量測（面積、直徑、周長、圓度）
    Batch Processing       整個資料夾一次處理
    Help                   說明

  最常用的流程 / The usual workflow:

    1. 到 Single Prediction，選一張影像
    2. 選標的類型：Cell（植物細胞）、Blood（血球）、Other（其他，
       例如根或真菌構造）
    3. 按 Start Prediction
    4. 到 Morphological Analysis 取得每個物件的量測值，可存成 CSV

    整個資料夾要處理時，用 Batch Processing 分頁。


標的類型怎麼選 / CHOOSING THE TARGET TYPE
--------------------------------------------------------------------

  Cell (Plant Cell)    植物細胞，例如馬鈴薯塊莖薄壁組織
  Blood (Blood Cell)   血球等圓形、彼此分離的物件
  Other (Other System) 其他標的：根、真菌捕捉環、菌絲等

  選錯類型會得到很差或全黑的結果——這是最常見的問題。
  Choosing the wrong type gives poor or empty results. This is the
  single most common mistake.


如果結果不理想 / IF THE RESULT LOOKS WRONG
--------------------------------------------------------------------

  結果全黑        → 把 Threshold 調低（試 0.3），並確認標的類型正確
  結果太雜        → 把 Threshold 調高（試 0.6–0.7）
  邊界黏在一起    → 調高 Threshold，並在形態分析設定最小面積
  很慢            → 確認 Model Management 選的是 GPU

  All black       → lower the Threshold (try 0.3); check the task type
  Too noisy       → raise the Threshold (try 0.6–0.7)
  Objects merged  → raise the Threshold; set a minimum area
  Very slow       → check that GPU is selected on Model Management


自己的資料怎麼訓練 / TRAINING ON YOUR OWN IMAGES
--------------------------------------------------------------------

  怎麼打開 / How to open it:

    桌面圖示「MultiTUNAparty Training」
    或 開始功能表 → MultiTUNAparty → MultiTUNAparty Training

    Desktop icon "MultiTUNAparty Training", or
    Start menu -> MultiTUNAparty -> MultiTUNAparty Training

  會先跳出一個黑色視窗，然後瀏覽器自動開啟 http://localhost:7860
  瀏覽器沒開的話自己貼這個網址就好。**那個黑色視窗不能關**，
  關掉訓練就停了。

  A console window opens first, then your browser at
  http://localhost:7860. If the browser does not open, paste that
  address yourself. **Do not close the console window** - closing it
  stops the training.

  如果缺少套件，啟動時會直接告訴你缺哪些、以及一行修復指令，
  不會讓你按下 Start Training 才發現失敗。

  If packages are missing, the launcher says which ones and gives you a
  one-line fix, instead of letting you press Start Training and fail.

  影像要放哪裡 / WHERE YOUR IMAGES GO

  安裝時已經幫你在「文件」底下建好一個資料夾，不用自己想路徑：
  The installer already made a folder for you under Documents, so
  there is no path to work out:

    文件\MultiTUNAparty\
      data\
        train\
          other\
            images\   （.jpg 影像 / your images）
            masks\    （.png 遮罩，檔名要和影像一樣 / masks, same names）
        val\
          other\
            images\
            masks\
      outputs\        （訓練結果會存在這裡 / results are saved here）

    Documents\MultiTUNAparty\ — same layout.

  開始功能表 → MultiTUNAparty → MultiTUNAparty Data Folder 可以直接打開。
  Start menu -> MultiTUNAparty -> MultiTUNAparty Data Folder opens it.

  訓練介面的 Data Path 欄位已經自動填好這個路徑，直接按
  Check Data Structure 就會檢查。第一次打開時資料夾是空的，
  會自動幫你把它開起來。

  The Data Path box in the training interface is already filled in with
  that folder, so you can press Check Data Structure straight away. On
  the first run the folder is empty and it opens in Explorer for you.

  遮罩是黑白兩色：白色是你要找的東西，黑色是背景。
  Masks are black and white: white is what you want to find.

  大概 train 20–60 張、val 5–15 張就能看到成效。
  20–60 images in train and 5–15 in val is enough to see a result.

  資料夾的名字有意義 / The folder name means something:
    cell\   植物細胞 plant cells    blood\  血球 blood cells
    other\  其他任何標的（根、真菌構造…）anything else

  新標的用 other\ 就好。/ Use other\ for a new target.

  訓練會從已安裝的模型接著練（介面上的 Use Pre-trained Model 已預先
  勾好，路徑也填好了）。這一點很重要：從零開始需要好幾千張影像，
  接著練只要幾十張。

  Training continues from the model that came with the program: the
  Use Pre-trained Model box is already ticked and its path filled in.
  This matters — from scratch would need thousands of images, whereas
  continuing from the shipped model needs only a few dozen.

  訓練完成後 / When it finishes:

    新模型在 文件\MultiTUNAparty\outputs\models\best_model.pth
    要用它：打開 MultiTUNAparty → Model Management → Browse 選這個檔
    → Load Model，辨識時任務類型選 Other。

    The new model is in Documents\MultiTUNAparty\outputs\models\.
    To use it: MultiTUNAparty -> Model Management -> Browse to that
    file -> Load Model, and choose the Other task type when predicting.


訓練介面說「Data path does not exist」/ "DATA PATH DOES NOT EXIST"
--------------------------------------------------------------------

  舊版的 Data Path 欄位預設是 data，指到程式自己的資料夾，那裡當然
  沒有你的影像。現在會自動填成上面那個「文件」裡的路徑。

  已經裝好舊版的人不用重裝，點兩下這個就好（幾秒鐘）：

    UPDATE.bat

  它會換掉啟動程式、換上新的圖示、重建捷徑、建好資料夾，
  不會動到 Python、PyTorch 或模型。

  An older build defaulted this box to data, which pointed inside the
  program's own folder. It is now filled in automatically.

  If it is already installed, there is no need to reinstall: just
  double-click UPDATE.bat. It refreshes the launcher scripts and the
  icons, rebuilds the shortcuts and creates the folders, in a few
  seconds. Python, PyTorch and the model are left alone.

  真的還是不行的話，把下面這行貼到 Data Path 欄位（把「你的帳號」
  換成你的 Windows 使用者名稱）：

    C:\Users\你的帳號\Documents\MultiTUNAparty\data

  If you still see the message, paste the path above into the Data Path
  box, with your own Windows user name.


怎麼移除 / HOW TO UNINSTALL
--------------------------------------------------------------------

  開始功能表 → MultiTUNAparty → Uninstall MultiTUNAparty

  或直接刪除這個資料夾 / or just delete this folder:
    %LOCALAPPDATA%\MultiTUNAparty

  你的影像和結果不會被刪除。
  Your own images and results are not touched.


安裝檔內容 / WHAT IS IN THIS FOLDER
--------------------------------------------------------------------

  INSTALL.bat            點兩下這個 / double-click this
  installer\             安裝腳本、圖示、套件清單
  app\                   MultiTUNAparty 程式碼本體（已內含）
  README_INSTALL.txt     這份說明
  UPDATE.bat             已經裝好時，只更新程式與圖示用的（幾秒鐘）
                         refreshes an existing installation in seconds
  MultiTUNAparty.iss     選用：打包成 .exe 用的
  build_installer_exe.bat

  **安裝檔已自帶程式碼**，可以直接拷到任何一台 Windows 電腦安裝，
  不需要另外下載或複製專案資料夾。

  The installer ships the application source inside app\, so it can be
  copied to any Windows computer and run on its own.


模型檔 / THE MODEL FILE
--------------------------------------------------------------------

  安裝程式會依序嘗試：
    1. 安裝檔旁邊的 best_model.pth
    2. 同一層的 outputs\models\best_model.pth
    3. 從 GitHub release 下載

  The installer looks for best_model.pth next to itself, then in
  outputs\models\, then tries the GitHub release.

  三個都沒有時，安裝仍會完成，第一次開啟程式會跳出提示，
  請到 Model Management 分頁按 Browse 選擇模型檔，或把
  best_model.pth 放到：

    %LOCALAPPDATA%\MultiTUNAparty\models\

  然後重新開啟程式。

  If none of the three works, the installation still completes. The
  program will prompt you on first launch: either browse to the model on
  the Model Management tab, or drop best_model.pth into the folder above
  and reopen it.

  離線散布最省事的作法：把 best_model.pth 放進這個資料夾再壓縮，
  收到的人解壓縮後點 INSTALL.bat 就全部搞定。
  For offline distribution, put best_model.pth in this folder before
  zipping it: whoever receives it just double-clicks INSTALL.bat.


安裝在第 5 步套件那裡失敗 / PACKAGE INSTALL FAILS AT STEP 5
--------------------------------------------------------------------

  安裝程式現在是一個一個套件裝的，失敗時會直接把 pip 的錯誤訊息
  印在畫面上，並指名是哪一個套件。

  The installer now installs packages one at a time. When one fails it
  prints pip's own error text and names the package.

  套件分成兩類 / Two groups:

    requirements-core.txt      辨識與量測必需（失敗會中止安裝）
                               Required for prediction; a failure stops
                               the installation.

    requirements-optional.txt  只有「訓練自己的模型」才需要
                               （albumentations、gradio）。
                               失敗只會警告，辨識功能完全不受影響。
                               Only needed to TRAIN a new target class.
                               A failure here is a warning only.

  必需套件失敗時 / If a required package fails:

    1. 先重跑一次。多半是網路中斷，已下載的部分會沿用。
       Just run it again; it is usually a dropped connection.

    2. 還是失敗的話，把畫面上那段 pip 訊息和紀錄檔寄出來。
       If it fails twice, send the pip text and the log file.


安裝時出現「未預期的語彙基元」/ PARSE ERRORS ON LAUNCH
--------------------------------------------------------------------

  如果一開始就跳出一堆紅字，提到「未預期的 'GB' 語彙基元」、
  「運算式中遺失 ')'」，而且訊息裡的中文是亂碼——

  那是 installer\setup.ps1 的 UTF-8 BOM 掉了。Windows PowerShell 5.1
  沒有 BOM 就會用系統編碼去讀腳本，中文變亂碼、引號被拆掉，整個檔案
  解析失敗。

  If the installer immediately prints parse errors mentioning unexpected
  tokens, and the Chinese in those messages looks like garbage, then
  installer\setup.ps1 lost its UTF-8 byte-order mark. Windows PowerShell
  5.1 reads script files in the system ANSI code page unless a BOM is
  present.

  解法 / Fixes, in order:

    1. 重新解壓縮一次原始的 zip（不要用會轉檔的工具）
       Re-extract from the original zip.

    2. 檢查檔案 / check the file:
         python installer\check_setup_ps1.py installer\setup.ps1

    3. 用英文模式跑，完全避開這個問題 / run English-only:
         powershell -NoProfile -ExecutionPolicy Bypass ^
           -File installer\setup.ps1 -SourceDir . -EnglishOnly

    4. 用記事本開啟 setup.ps1，另存新檔，編碼選「UTF-8 with BOM」
       Open setup.ps1 in Notepad, Save As, encoding "UTF-8 with BOM".


出問題的時候 / IF SOMETHING GOES WRONG
--------------------------------------------------------------------

  安裝的紀錄檔 / installation log:
    %LOCALAPPDATA%\MultiTUNAparty\install_log.txt

  程式的錯誤紀錄 / program error log:
    %LOCALAPPDATA%\MultiTUNAparty\error_log.txt

  安裝到一半斷掉時，直接重跑 INSTALL.bat 就好，
  已經下載好的部分會沿用，不會重來。
  If the install is interrupted, just run INSTALL.bat again —
  it reuses whatever already downloaded.

  請把上面兩個檔案寄給 / send those two files to:
    shitephenwang@ntu.edu.tw


沒有網路的電腦 / COMPUTERS WITHOUT INTERNET
--------------------------------------------------------------------

  把 best_model.pth 放在 INSTALL.bat 旁邊，安裝程式就會
  直接用它，不會嘗試下載。

  Put best_model.pth next to INSTALL.bat and the installer
  will use it instead of downloading.

  套件的部分仍需要網路。若要完全離線，請先在一台有網路的電腦執行：
  Packages still need internet. For a fully offline install, first run
  this on a connected computer:

    pip download -r installer\requirements.txt -d wheels
    pip download torch torchvision --index-url https://download.pytorch.org/whl/cu124 -d wheels

  再把 wheels 資料夾一起帶過去。
  Then carry the wheels folder along.


做成單一 .exe 安裝檔 / BUILDING A SINGLE .EXE
--------------------------------------------------------------------

  給不熟悉 .bat 的使用者時，可以做成一般的安裝精靈：

    1. 安裝 Inno Setup 6（免費）https://jrsoftware.org/isdl.php
    2. 點兩下 build_installer_exe.bat
    3. 產生 dist\MultiTUNAparty-Setup.exe

  把 best_model.pth 放進來一起打包，就變成完全離線的安裝檔
  （檔案會大約 500 MB）。

====================================================================
  授權 MIT License   作者 Shitephen Wang
  國立臺灣大學 森林環境暨資源學系
  https://github.com/gn03138868/multiTUNAparty-model
====================================================================
