@echo off
REM MultiTUNAparty installer launcher.
REM ASCII-only on purpose: cmd.exe reads .bat in the OEM code page.
chcp 65001 >nul 2>&1
title MultiTUNAparty Installer
cls
echo.
echo   ==========================================================
echo    MultiTUNAparty  -  Installer
echo    Identify and measure cells, roots and fungal structures
echo   ==========================================================
echo.
echo    Starting the installer...
echo.

set "HERE=%~dp0"
REM %~dp0 ends with a backslash. Passed as -SourceDir "%HERE%" that trailing
REM backslash escapes the closing quote, so PowerShell receives a path with a
REM stray " on the end. Strip it.
if "%HERE:~-1%"=="\" set "HERE=%HERE:~0,-1%"

set "PS1=%HERE%\installer\setup.ps1"

if not exist "%PS1%" (
  echo.
  echo   [X] Could not find installer\setup.ps1
  echo.
  echo       Make sure the whole folder was extracted, and that this file
  echo       sits next to app_gui_en.py
  echo.
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%" -SourceDir "%HERE%"
if errorlevel 1 goto :failed
exit /b 0

:failed
echo.
echo   The installation did not finish.
echo   Log: %LOCALAPPDATA%\MultiTUNAparty\install_log.txt
echo.
echo   The message above should name the step and the package that failed.
echo   Send that line plus the log file to the developer.
echo.
echo   To retry in English only:
echo       powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%" -SourceDir "%HERE%" -EnglishOnly
echo.
pause
exit /b 1
