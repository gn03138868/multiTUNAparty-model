@echo off
chcp 65001 >nul 2>&1
title Build MultiTUNAparty-Setup.exe
echo.
echo   打包成單一 .exe 安裝檔 / Building a single .exe installer
echo.

set "ISCC="
for %%P in (
  "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
  "%ProgramFiles%\Inno Setup 6\ISCC.exe"
  "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
) do if exist %%P set "ISCC=%%~P"

if not defined ISCC (
  echo   X  找不到 Inno Setup 6 / Inno Setup 6 not found
  echo.
  echo      請先安裝（免費）/ Please install it first, it is free:
  echo      https://jrsoftware.org/isdl.php
  echo.
  pause
  exit /b 1
)

if not exist "LICENSE.txt" (
  echo MIT License > LICENSE.txt
  echo. >> LICENSE.txt
  echo Copyright (c) 2026 Shitephen Wang >> LICENSE.txt
  echo. >> LICENSE.txt
  echo Permission is hereby granted, free of charge, to any person obtaining a copy >> LICENSE.txt
  echo of this software and associated documentation files (the "Software"), to deal >> LICENSE.txt
  echo in the Software without restriction. >> LICENSE.txt
  echo. >> LICENSE.txt
  echo THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND. >> LICENSE.txt
)

if not exist "app_gui_en.py" (
  echo   X  找不到 app_gui_en.py
  echo      Copy the application .py files next to this script first.
  echo.
  pause
  exit /b 1
)

echo   使用 / using: %ISCC%
echo.
"%ISCC%" MultiTUNAparty.iss
if errorlevel 1 (
  echo.
  echo   打包失敗 / build failed
  pause
  exit /b 1
)
echo.
echo   完成 / done:  dist\MultiTUNAparty-Setup.exe
echo.
pause
